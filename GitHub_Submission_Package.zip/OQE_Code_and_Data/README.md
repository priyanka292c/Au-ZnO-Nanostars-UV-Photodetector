# Au-ZnO Nanostar-Enhanced Ultraviolet Photodetector: Computational Inverse Design and Multiphysics Modeling Package

This repository contains the complete simulation models, raw numerical datasets, and Python reproduction scripts supporting the research article:

**"Generation–Depletion Co-Localization and Carrier Extraction in Embedded Au Nanostar-Enhanced ZnO Ultraviolet Photodetectors: A Multiphysics Modelling Study"**  
*Authors:* Priyanka (Univ. of Delhi) and Dr. Ram Soorat (Woxsen Univ.)  
*Target Journal:* **Optical and Quantum Electronics** (Springer Nature)

---

## 1. Directory Structure and Contents

| File / Folder | Type | Description |
|---|:---:|---|
| `generate_acs_10_figures.py` | Python Script | Primary master script reproducing all 10 high-resolution publication figures (Figures 1–10). |
| `nanostar_inverse_design.py` | Python Script | Gaussian Process Bayesian Optimization (GP-BO) active learning code for 5D structural optimization. |
| `export_all_nanostar_csv.py` | Python Script | Utility script exporting consolidated simulation outputs to tabular CSV format. |
| `carrier_generation_profile.csv` | Dataset | Spatially resolved 1D and 3D optical carrier photogeneration rate profiles $G_{\mathrm{opt}}(z)$ across active ZnO thickness. |
| `optical_spectra.csv` | Dataset | Absorption ($A$), scattering ($S$), extinction ($E$), and bottom-mirror reflectance ($R$) spectra from 300 to 500 nm. |
| `geometry_sweep.csv` | Dataset | Geometric parametric sweeps over core radius ($r_{\mathrm{core}}$), tip length ($L_{\mathrm{tip}}$), apex radius ($r_{\mathrm{apex}}$), and number of arms. |
| `embedding_depth_sweep.csv` | Dataset | Embedding depth ($h_{\mathrm{embed}} = 0\text{--}150\,\mathrm{nm}$) sweep tracking the overlap factor $\Gamma_{\mathrm{PD}}$ and responsivity. |
| `device_metrics.csv` | Dataset | Complete 80-configuration validation dataset containing $\Gamma_{\mathrm{PD}}$, $|E/E_0|^2$, $\eta_{\mathrm{col}}$, and responsivity $\mathcal{R}$. |
| `iv_curves.csv` / `iv_characteristics.csv` | Dataset | Dark and illuminated $J$--$V$ characteristics (0 to 5 V reverse bias) with and without Au nanostar incorporation. |
| `responsivity_eqe_detectivity.csv` | Dataset | Bias-dependent responsivity ($\mathcal{R}$), external quantum efficiency ($\mathrm{EQE}$), and shot-noise-limited detectivity ($D^*$). |
| `transient_switching_dynamics.csv` | Dataset | Transient pulse switching kinetics under a 40 ns optical pulse ($\tau_r = 8.4\,\mathrm{ns}$, $\tau_f = 21.2\,\mathrm{ns}$). |
| `pareto_optimal_frontier.csv` | Dataset | Bi-objective Pareto frontier data balancing responsivity $\mathcal{R}$ against response time $\tau_f$. |
| `sobol_sensitivity_indices.csv` | Dataset | First-order ($S_i$) and total-order ($S_{Ti}$) Sobol variance-based global sensitivity indices. |
| `monte_carlo_distribution.csv` | Dataset | 1,000-trial Monte Carlo tolerance evaluation accounting for $\pm 10\%$ fabrication variations in nanostar geometry. |
| `nanorod_benchmark/` | Sub-directory | Electrodynamic and transport benchmarking datasets for 1D Au nanorods under identical ZnO active layer conditions. |

---

## 2. Environment and Requirements

- Python $\ge$ 3.8
- `numpy` $\ge$ 1.20
- `scipy` $\ge$ 1.7
- `matplotlib` $\ge$ 3.4
- `pandas` $\ge$ 1.3

Install required packages via:
```bash
pip install numpy scipy matplotlib pandas
```

---

## 3. Reproducing Publication Figures

To re-render all 10 publication figures at 600 DPI vector/raster format:
```bash
python generate_acs_10_figures.py
```
Output files will be generated as vector `.pdf` and high-resolution `.png` files in the working directory.

---

## 4. License and Citation

All code and data are provided under the MIT Open Source License. If using these datasets or models, please cite:
Priyanka and R. Soorat, *"Generation–Depletion Co-Localization and Carrier Extraction in Embedded Au Nanostar-Enhanced ZnO Ultraviolet Photodetectors: A Multiphysics Modelling Study"*, Optical and Quantum Electronics (2026).

