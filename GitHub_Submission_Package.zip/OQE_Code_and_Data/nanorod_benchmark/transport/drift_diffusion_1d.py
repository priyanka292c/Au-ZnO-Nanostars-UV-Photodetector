#!/usr/bin/env python3
"""
drift_diffusion_1d.py
1D Poisson-coupled drift-diffusion solver input parameters and carrier extraction model
for the embedded Au nanorod benchmark.
"""

def get_transport_parameters():
    return {
        "material": "ZnO",
        "bandgap_eV": 3.37,
        "static_permittivity": 8.5,
        "donor_doping_cm3": 8.2e17,
        "electron_mobility_cm2_V_s": 28.0,
        "hole_mobility_cm2_V_s": 5.0,
        "bulk_SRH_tau_n_ns": 10.0,
        "bulk_SRH_tau_p_ns": 5.0,
        "trapped_hole_lifetime_ns": 14.8,
        "transit_time_ns": 2.81,
        "photoconductive_gain": 5.26,
        "surface_recomb_velocity_cm_s": 1.0e4,
        "interface_recomb_velocity_cm_s": 5.0e3,
        "built_in_potential_V": 0.72,
        "schottky_barrier_height_eV": 0.80,
        "reverse_bias_V": 3.0,
        "depletion_width_nm": 65.4,
        "nanorod_centroid_depth_nm": 50.0,
        "collection_efficiency_percent": 76.5,
        "drift_sweepout_time_ps": 2.05
    }

if __name__ == "__main__":
    params = get_transport_parameters()
    print("Transport Parameters for Embedded Au Nanorod Benchmark:")
    for k, v in params.items():
        print(f"  {k}: {v}")
