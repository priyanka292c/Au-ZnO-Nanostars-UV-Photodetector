# Independent Nanorod Benchmark Simulation

This benchmark reproduces the internal computational control for an embedded Au nanorod photodetector reported in:
**"Generation–Depletion Co-Localization in Embedded Au Nanostar-Enhanced ZnO Ultraviolet Photodetectors"** (*ACS Applied Optical Materials*, 2026).

---

## 1. Physical Specifications

| Parameter | Symbol | Value | Unit |
|---|---|---|---|
| Total Axial Length | $L$ | 80 | nm |
| Cylinder Diameter | $D$ | 25 | nm |
| End-Cap Radius | $r$ | 12.5 | nm |
| Cylindrical Core Length | $L_{\mathrm{cyl}}$ | 55 | nm |
| Aspect Ratio | $\mathrm{AR}$ | 3.2 | — |
| Au Volume | $V_{\mathrm{rod}}$ | 35,179 | nm³ |
| Host Matrix | ZnO thin film | 200 | nm |
| Embedding Depth (centroid) | $h_{\mathrm{embed}}$ | 50 | nm |
| Unit Cell Lattice Pitch | $P$ | 300 | nm |
| Depletion Width (3 V) | $W_D$ | 65.4 | nm |
| Excitation Wavelength | $\lambda$ | 365 | nm |
| Optical Power Density | $P_{\mathrm{inc}}$ | 10 | W m⁻² |
| Longitudinal LSPR | $\lambda_{\mathrm{LSPR}}$ | ~872 | nm |

> **Key Physical Distinction:** The dipolar longitudinal LSPR of this Au nanorod resides in the near-infrared ($\lambda \approx 872$\,nm). Excitation at $\lambda = 365$\,nm operates in the off-resonant UV regime, where the $1.25$\,A\,W$^{-1}$ responsivity is attained exclusively because lightning-rod end-cap field crowding remains spatially co-localized inside the $65.4$\,nm Schottky depletion field ($\Gamma_{\mathrm{NF-D}} = 74.2\%$).

---

## 2. Directory Structure

```text
nanorod_benchmark/
    |-- README.md                      # Workflow, benchmark parameters, and equations
    |-- geometry/                      # 3D CAD/STL files (80 x 25 nm, hemispherical caps)
    |-- FDTD/                          # Full-wave FDTD scripts (Python-Meep / Lumerical)
    |-- material_parameters/           # Dielectric functions for Au (size-corrected) & ZnO
    |-- polarization_sweep/            # Polarization FDTD scripts & spectra (0 to 90 deg)
    |-- transport/                     # Poisson--drift-diffusion solver input decks & code
    |-- raw_data/                      # Tabulated generation rates, J-V curves, responsivity
    \-- responsivity_calculation/      # Python post-processing and verification scripts
```

---

## 3. Results Summary

- **Polarization Sweep ($\lambda = 365$\,nm):**
  - $\theta_{\mathrm{pol}} = 0^\circ$ (longitudinal): $A_{\mathrm{ZnO}} = 64.5\%$, $\mathcal{R} = 1.25$\,A\,W$^{-1}$
  - $\theta_{\mathrm{pol}} = 30^\circ$: $A_{\mathrm{ZnO}} = 49.8\%$, $\mathcal{R} = 0.94$\,A\,W$^{-1}$
  - $\theta_{\mathrm{pol}} = 45^\circ$: $A_{\mathrm{ZnO}} = 34.2\%$, $\mathcal{R} = 0.62$\,A\,W$^{-1}$
  - $\theta_{\mathrm{pol}} = 60^\circ$: $A_{\mathrm{ZnO}} = 20.4\%$, $\mathcal{R} = 0.35$\,A\,W$^{-1}$
  - $\theta_{\mathrm{pol}} = 90^\circ$ (transverse): $A_{\mathrm{ZnO}} = 8.5\%$, $\mathcal{R} = 0.14$\,A\,W$^{-1}$
- **Polarization Anisotropy:** $\Delta\mathcal{R}/\mathcal{R}_{\mathrm{avg}} = 88.8\%$
- **Field-Depletion Overlap:** $\Gamma_{\mathrm{NF-D}} = 74.2\%$
- **Carrier Extraction:** $\eta_{\mathrm{col}} = 76.5\%$, $G = 5.26$, $\tau_{\mathrm{drift}} = 2.05$\,ps
- **Responsivity:** $\mathcal{R} = \mathcal{R}_{\mathrm{inter}} + \mathcal{R}_{\mathrm{hot}} = 1.025 + 0.225 = 1.250$\,A\,W$^{-1}$
