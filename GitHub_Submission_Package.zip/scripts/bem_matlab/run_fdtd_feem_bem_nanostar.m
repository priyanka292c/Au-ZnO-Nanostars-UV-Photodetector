% =========================================================================
% run_fdtd_feem_bem_nanostar.m — Legacy Entrypoint (Redirects to Nanostars Suite)
% =========================================================================
function run_fdtd_feem_bem_nanostar()
    automate_fdtd_feem_bem_nanostars();
end
