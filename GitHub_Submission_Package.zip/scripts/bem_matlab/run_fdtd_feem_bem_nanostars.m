% =========================================================================
% run_fdtd_feem_bem_nanostars.m — Entrypoint for MATLAB Multi-Physics Suite
% =========================================================================
function run_fdtd_feem_bem_nanostars()
    automate_fdtd_feem_bem_nanostars();
end
