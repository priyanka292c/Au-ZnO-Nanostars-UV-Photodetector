% =========================================================================
% bem_nanostar_plasmonics.m — Forwarding wrapper to bem_nanostars_plasmonics.m
% =========================================================================
function results = bem_nanostar_plasmonics(varargin)
    results = bem_nanostars_plasmonics(varargin{:});
end
