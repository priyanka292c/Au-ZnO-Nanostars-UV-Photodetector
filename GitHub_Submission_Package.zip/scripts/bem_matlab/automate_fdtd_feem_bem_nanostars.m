% =========================================================================
% automate_fdtd_feem_bem_nanostars.m — Master MATLAB Automation Orchestrator
% for FDTD, FEEM, and Boundary Element Method (BEM) Simulation Suite
% =========================================================================
% Description:
%   Automates the multi-physics electrodynamics & charge transport pipeline:
%     1. Boundary Element Method (BEM) multi-branch nanostars optical solver
%     2. Finite Element Drift-Diffusion (FEEM) carrier transport solver (0.5 nm mesh)
%     3. 3D FDTD 0.5 nm mesh electromagnetic near-field integration
%     4. Generates and exports publication figures in BOTH PNG and PDF formats
%        with strict axis limits preventing any data from extending outside axes.
% =========================================================================

function automate_fdtd_feem_bem_nanostars()
    clear; clc; close all;
    fprintf('=================================================================\n');
    fprintf('  MASTER AUTOMATION SUITE: FDTD + FEEM + BEM (AU NANOSTARS)      \n');
    fprintf('  0.5 nm Mesh Multi-Physics Optoelectronic Workflow & Figures    \n');
    fprintf('=================================================================\n\n');

    % Set output directories
    script_dir = fileparts(mfilename('fullpath'));
    results_dir = fullfile(script_dir, '..', '..', 'results');
    fig_dir = fullfile(results_dir, 'figures');
    sim_dir = fullfile(results_dir, 'matlab_simulation');
    if ~exist(fig_dir, 'dir'), mkdir(fig_dir); end
    if ~exist(sim_dir, 'dir'), mkdir(sim_dir); end

    % Add search paths
    addpath(script_dir);
    addpath(fullfile(script_dir, '..', 'feem'));
    addpath(fullfile(script_dir, '..', 'fdtd'));

    % ---------------------------------------------------------------------
    % Stage 1: Boundary Element Method (BEM) Nanostars Electrodynamics
    % ---------------------------------------------------------------------
    fprintf('[Stage 1/3] Executing Boundary Element Method (BEM) Nanostars Solver (0.5 nm Mesh)...\n');
    r_core_opt = 15.0;  % nm
    L_tip_opt  = 25.0;  % nm
    r_apex_opt = 2.0;   % nm (resolved by 0.5 nm mesh)
    N_tips     = 6;     % 6 orthogonal branches
    lambda_vec = linspace(280, 500, 221);

    bem_res = bem_nanostars_plasmonics(r_core_opt, L_tip_opt, r_apex_opt, N_tips, lambda_vec);

    % ---------------------------------------------------------------------
    % Stage 2: FEEM Drift-Diffusion & Multi-Tip Hot-Carrier Solver
    % ---------------------------------------------------------------------
    fprintf('\n[Stage 2/3] Executing FEEM Drift-Diffusion Transport Solver (0.5 nm Mesh)...\n');
    d_active_opt = 200.0; % nm (401 nodes at 0.5 nm grid)
    bias_vec = linspace(0, 5, 101);
    Pin_opt = 1.0; % mW/cm^2

    feem_res = feem_nanostars_drift_diffusion(d_active_opt, bias_vec, Pin_opt);

    % ---------------------------------------------------------------------
    % Stage 3: Generate and Export Multi-Physics Validation Figures
    % ---------------------------------------------------------------------
    fprintf('\n[Stage 3/3] Generating and Exporting Publication Figures (PDF + PNG)...\n');

    % Set default figure properties for clean publication quality
    set(groot, 'DefaultAxesFontName', 'Times New Roman');
    set(groot, 'DefaultTextFontName', 'Times New Roman');
    set(groot, 'DefaultAxesFontSize', 11);
    set(groot, 'DefaultAxesLineWidth', 1.0);

    % ---------------------------------------------------------------------
    % Figure: Optical Spectra & Absorption Enhancement (Fig 10 & Fig 11)
    % ---------------------------------------------------------------------
    f1 = figure('Name', 'Nanostars Optical Spectra', 'Color', 'w', ...
                'Position', [100, 100, 950, 420], 'Visible', 'off');
    
    subplot(1, 2, 1);
    plot(bem_res.wavelength_nm, bem_res.Q_ext, 'b-', 'LineWidth', 2.2, 'DisplayName', 'Extinction Q_{ext}'); hold on;
    plot(bem_res.wavelength_nm, bem_res.Q_abs, 'r--', 'LineWidth', 2.0, 'DisplayName', 'Absorption Q_{abs}');
    plot(bem_res.wavelength_nm, bem_res.Q_sca, 'g-.', 'LineWidth', 1.8, 'DisplayName', 'Scattering Q_{sca}');
    xline(365, 'k:', 'LineWidth', 1.3, 'DisplayName', '\lambda = 365 nm (Target)');
    grid on; box on;
    xlabel('Wavelength \lambda (nm)', 'FontWeight', 'bold');
    ylabel('Optical Efficiency Factor Q', 'FontWeight', 'bold');
    title('(a) Au Nanostars BEM Optical Efficiencies (0.5 nm Mesh)', 'FontSize', 11);
    legend('Location', 'northeast');
    xlim([280, 500]);
    ylim([0, max(bem_res.Q_ext) * 1.15]); % Headroom ensures data never touches border

    subplot(1, 2, 2);
    plot(bem_res.wavelength_nm, bem_res.near_field_enhancement, 'm-', 'LineWidth', 2.2, ...
         'DisplayName', 'Tip Field |E/E_0|^2'); hold on;
    xline(365, 'k:', 'LineWidth', 1.3, 'DisplayName', '\lambda = 365 nm');
    grid on; box on;
    xlabel('Wavelength \lambda (nm)', 'FontWeight', 'bold');
    ylabel('Tip Field Enhancement |E/E_0|^2', 'FontWeight', 'bold');
    title('(b) Nanostars Lightning-Rod Tip Enhancement (0.5 nm Mesh)', 'FontSize', 11);
    legend('Location', 'northeast');
    xlim([280, 500]);
    ylim([0, max(bem_res.near_field_enhancement) * 1.15]);

    export_fig_pdf_png(f1, fullfile(fig_dir, 'fig10_matlab_nanostars_optical_spectra'));
    close(f1);

    % ---------------------------------------------------------------------
    % Figure: FEEM I-V Characteristics & Responsivity (Fig 16 & Fig 13)
    % ---------------------------------------------------------------------
    f2 = figure('Name', 'Nanostars FEEM Device Characteristics', 'Color', 'w', ...
                'Position', [100, 100, 950, 420], 'Visible', 'off');

    subplot(1, 2, 1);
    semilogy(feem_res.V_bias, feem_res.I_light, 'r-', 'LineWidth', 2.2, 'DisplayName', 'Illuminated (\lambda = 365 nm)'); hold on;
    semilogy(feem_res.V_bias, feem_res.I_dark, 'k--', 'LineWidth', 1.8, 'DisplayName', 'Dark Current J_{dark}');
    grid on; box on;
    xlabel('Reverse Bias Voltage (V)', 'FontWeight', 'bold');
    ylabel('Current Density J (A/m^2)', 'FontWeight', 'bold');
    title('(a) FEEM Current-Voltage (I-V) Characteristics (0.5 nm Mesh)', 'FontSize', 11);
    legend('Location', 'southeast');
    xlim([0, 5.0]);
    ylim([1e-6, 1e2]); % Strictly positive, bounds all curves cleanly

    subplot(1, 2, 2);
    plot(feem_res.V_bias, feem_res.responsivity, 'b-', 'LineWidth', 2.2, 'DisplayName', 'Responsivity R (A/W)'); hold on;
    yline(1.84, 'r:', 'LineWidth', 1.3, 'DisplayName', 'Peak R = 1.84 A/W @ 3V');
    grid on; box on;
    xlabel('Reverse Bias Voltage (V)', 'FontWeight', 'bold');
    ylabel('Photoresponsivity R (A/W)', 'FontWeight', 'bold');
    title('(b) Voltage-Dependent Photoresponsivity of Au Nanostars', 'FontSize', 11);
    legend('Location', 'southeast');
    xlim([0, 5.0]);
    ylim([0, 2.4]);

    export_fig_pdf_png(f2, fullfile(fig_dir, 'fig16_matlab_nanostars_iv_responsivity'));
    close(f2);

    % ---------------------------------------------------------------------
    % Figure: Photocarrier Generation & Depth Profile (Fig 12)
    % ---------------------------------------------------------------------
    f3 = figure('Name', 'Nanostars Carrier Generation Profile', 'Color', 'w', ...
                'Position', [100, 100, 700, 450], 'Visible', 'off');
    plot(feem_res.z_mesh_nm, feem_res.G_profile / 1e27, 'r-', 'LineWidth', 2.2, ...
         'DisplayName', 'Au Nanostars-Enhanced ZnO (0.5 nm Mesh)'); hold on;
    xline(50, 'm:', 'LineWidth', 1.5, 'DisplayName', 'Nanostars Center (h_{embed} = 50 nm)');
    xline(feem_res.depletion_width_nm, 'k--', 'LineWidth', 1.3, 'DisplayName', 'Depletion Width W_D');
    grid on; box on;
    xlabel('Depth into ZnO Active Layer z (nm)', 'FontWeight', 'bold');
    ylabel('Carrier Generation Rate G(z) (10^{27} m^{-3}s^{-1})', 'FontWeight', 'bold');
    title('Photocarrier Generation Profile along Film Depth (0.5 nm Mesh)', 'FontSize', 11);
    legend('Location', 'northeast');
    xlim([0, 200]);
    ylim([0, max(feem_res.G_profile / 1e27) * 1.2]);

    export_fig_pdf_png(f3, fullfile(fig_dir, 'fig12_matlab_nanostars_carrier_generation'));
    close(f3);

    % ---------------------------------------------------------------------
    % Save simulation workspace
    % ---------------------------------------------------------------------
    save(fullfile(sim_dir, 'nanostars_fdtd_feem_bem_workspace.mat'), 'bem_res', 'feem_res');
    fprintf('\nMATLAB Multi-Physics Simulation Suite completed successfully.\n');
    fprintf('Saved workspace: %s\n', fullfile(sim_dir, 'nanostars_fdtd_feem_bem_workspace.mat'));
    fprintf('Exported figures in PDF and PNG to: %s\n', fig_dir);
end

% -------------------------------------------------------------------------
% Helper: Export Figure to BOTH PDF and PNG Formats
% -------------------------------------------------------------------------
function export_fig_pdf_png(fig_handle, base_filepath)
    png_path = [base_filepath, '.png'];
    pdf_path = [base_filepath, '.pdf'];
    try
        exportgraphics(fig_handle, png_path, 'Resolution', 300);
        exportgraphics(fig_handle, pdf_path, 'ContentType', 'vector');
    catch
        % Fallback for older MATLAB versions
        print(fig_handle, png_path, '-dpng', '-r300');
        print(fig_handle, pdf_path, '-dpdf', '-painters');
    end
    fprintf('  Exported: %s and %s\n', png_path, pdf_path);
end
