% =========================================================================
% feem_nanostar_drift_diffusion.m — Forwarding wrapper to feem_nanostars_drift_diffusion.m
% =========================================================================
function device_out = feem_nanostar_drift_diffusion(varargin)
    device_out = feem_nanostars_drift_diffusion(varargin{:});
end
