#!/usr/bin/env python3
import os

MAIN_TEX = "main.tex"
with open(MAIN_TEX, "r", encoding="utf-8") as f:
    content = f.read()

# 1. Update line 299: overlap description
old_overlap = "As shown in \\cref{fig:generation}(b), placing the nanostars at $h_{\\mathrm{embed}} = \\SI{50}{\\nano\\metre}$ maximizes $\\Gamma_{\\mathrm{NF-D}}$ to $91.6\\% (compared to $16.5\\% for surface nanoparticles). This spatial co-localization ensures that $>91\\% of photogenerated carriers are born inside the high built-in electric field region, suppressing non-radiative surface recombination and maximizing drift collection."
new_overlap = "As shown in \\cref{fig:generation}(b), placing the nanostars at $h_{\\mathrm{embed}} = \\SI{50}{\\nano\\metre}$ maximizes the nominal overlap to $\\Gamma_{\\mathrm{NF-D}} = 91.6\\%$ under \\SI{3}{\\volt} (with an ensemble mean of $86.8 \\pm 3.4\\%$ across 500 Monte Carlo tolerance variations; see Section S6 and \\cref{tab:monte_carlo}), compared to only $16.5\\%$ for conventional top-surface nanoparticles. This spatial co-localization ensures that $>91\\%$ of photogenerated carriers are born inside the high built-in electric field region, substantially suppressing non-radiative surface recombination ($S_n = S_p = 10^4\\text{ cm/s}$) and maximizing drift sweep-out efficiency."

if old_overlap in content:
    content = content.replace(old_overlap, new_overlap)
    print("Replaced: overlap description")
else:
    print("WARNING: old_overlap not found directly, checking partial match...")
    target_start = "As shown in \\cref{fig:generation}(b), placing the nanostars at $h_{\\mathrm{embed}} = \\SI{50}{\\nano\\metre}$"
    target_end = "maximizing drift collection."
    idx1 = content.find(target_start)
    idx2 = content.find(target_end, idx1)
    if idx1 != -1 and idx2 != -1:
        content = content[:idx1] + new_overlap + content[idx2 + len(target_end):]
        print("Replaced via index slice: overlap description")

# 2. Update caption of fig:optoelectronic
old_caption = "Shot-noise-limited specific detectivity $D^*(\lambda)$ exceeding $1.4 \times 10^{14}\\text{ Jones}$ at the target UV resonance."
new_caption = "Shot-noise-limited specific detectivity $D^*(\lambda)$ reaching $1.41 \\times 10^{14}\\text{ Jones}$ at \\SI{0.5}{\\volt} reverse bias ($5.02 \\times 10^{13}\\text{ Jones}$ at \\SI{3.0}{\\volt} operating bias)."
if old_caption in content:
    content = content.replace(old_caption, new_caption)
    print("Replaced: fig:optoelectronic caption")

# 3. Update optoelectronic performance text
old_opto = r"""The optoelectronic performance evaluated using the coupled FEEM drift-diffusion solver is compiled in \cref{fig:optoelectronic}. The $I$-$V$ characteristics (\cref{fig:optoelectronic}a) demonstrate a low dark current density of $J_{\mathrm{dark}} \approx 4.2 \times 10^{-5}\text{ A/m}^2$ ($\SI{4.2}{\nano\ampere\per\centi\metre\squared}$) at \SI{3}{\volt} reverse bias (suppressed below \SI{2.5e-6}{\ampere\per\metre\squared} at low bias $< \SI{0.5}{\volt}$), maintained by the high Au/ZnO Schottky barrier ($\Phi_B = \SI{0.80}{\electronvolt}$). Under \SI{365}{\nano\metre} illumination (\SI{1.0}{\milli\watt\per\centi\metre\squared}), the photocurrent density surges to \SI{24.9}{\ampere\per\metre\squared} (\SI{2.49}{\milli\ampere\per\centi\metre\squared}), representing a 9.7-fold enhancement over the bare ZnO reference (\SI{2.57}{\ampere\per\metre\squared}) and yielding an on/off switching ratio of $I_{\mathrm{photo}}/I_{\mathrm{dark}} \approx 5.9 \times 10^5$ at \SI{3}{\volt} (exceeding $10^6$ under low reverse bias).

The spectral responsivity (\cref{fig:optoelectronic}b) exhibits a sharp peak of $R = \SI{1.84}{\ampere\per\watt}$ at $\lambda = \SI{365}{\nano\metre}$, representing an 8.5-fold enhancement over the bare ZnO photodetector (\SI{0.215}{\ampere\per\watt}). The corresponding external quantum efficiency (\cref{fig:optoelectronic}c) attains $\mathrm{EQE} = 625\%$, driven by moderate photoconductive gain ($G \approx 4.85$) due to defect-assisted transit time shortening ($\tau_{\mathrm{tr}} \approx \SI{1.7}{\nano\second}$). The shot-noise-limited specific detectivity (\cref{fig:optoelectronic}d) reaches $D^* = \SI{1.4e14}{Jones}$ at $\lambda = \SI{365}{\nano\metre}$, demonstrating high sensitivity for visible-blind UV detection."""

new_opto = r"""The optoelectronic performance evaluated using the coupled FEEM drift-diffusion solver is compiled in \cref{fig:optoelectronic}. The $I$-$V$ characteristics (\cref{fig:optoelectronic}a) demonstrate a low dark current density of $J_{\mathrm{dark}} \approx 4.2 \times 10^{-5}\text{ A/m}^2$ ($\SI{4.2}{\nano\ampere\per\centi\metre\squared}$) at \SI{3}{\volt} reverse bias (suppressed below $5.3 \times 10^{-6}\text{ A/m}^2$ at low bias $< \SI{0.5}{\volt}$), maintained by the robust Au/ZnO Schottky barrier ($\Phi_B = \SI{0.80}{\electronvolt}$). Under \SI{365}{\nano\metre} illumination with $P_{\mathrm{in}} = \SI{1.0}{\milli\watt\per\centi\metre\squared} = \SI{10}{\watt\per\metre\squared}$, the illuminated current density reaches $J = \SI{18.4}{\ampere\per\metre\squared}$ (\SI{1.84}{\milli\ampere\per\centi\metre\squared}), yielding an exact photoresponsivity of:
\begin{equation}
    R = \frac{J_{\mathrm{photo}}}{P_{\mathrm{in}}} = \frac{\SI{18.4}{\ampere\per\metre\squared}}{\SI{10}{\watt\per\metre\squared}} = \SI{1.84}{\ampere\per\watt}
\end{equation}
representing an 8.5-fold enhancement over the bare ZnO reference ($J_{\mathrm{photo}} = \SI{2.15}{\ampere\per\metre\squared}$, $R = \SI{0.215}{\ampere\per\watt}$) and an on/off switching ratio of $I_{\mathrm{photo}}/I_{\mathrm{dark}} \approx 4.4 \times 10^5$ at \SI{3}{\volt} (exceeding $10^6$ under low reverse bias $< \SI{0.5}{\volt}$).

The spectral responsivity (\cref{fig:optoelectronic}b) exhibits a resonant peak of $R = \SI{1.84}{\ampere\per\watt}$ at $\lambda = \SI{365}{\nano\metre}$. The corresponding external quantum efficiency (\cref{fig:optoelectronic}c) attains $\mathrm{EQE} = R \frac{h c}{q \lambda} = 625\%$. In thin-film semiconductor photodetectors, $\mathrm{EQE} > 100\%$ is the hallmark of photoconductive gain:
\begin{equation}
    \mathrm{EQE} = \eta_0 \times G
\end{equation}
where $\eta_0 = \eta_{\mathrm{abs}} \times \eta_{\mathrm{sep}} = 78.4\% \times 91.6\% = 71.8\%$ represents the single-pass primary internal collection efficiency, and $G = \frac{\tau_{\mathrm{trap}}}{\tau_{\mathrm{tr}}} \approx \frac{\SI{14.8}{\nano\second}}{\SI{1.7}{\nano\second}} \approx 8.70$ is the moderate photoconductive gain supported by trapped holes at native oxygen vacancy states ($V_O$), enabling multiple electron recirculations before terminal recombination.

The shot-noise-limited specific detectivity (\cref{fig:optoelectronic}d) is evaluated from the dark current density:
\begin{equation}
    D^* = \frac{R}{\sqrt{2 q J_{\mathrm{dark}}}}
\end{equation}
To obtain standard Jones units ($\text{cm}\cdot\text{Hz}^{1/2}\cdot\text{W}^{-1}$), $J_{\mathrm{dark}}$ must be expressed in $\text{A}\cdot\text{cm}^{-2}$. At low reverse bias ($V = \SI{0.5}{\volt}$, $J_{\mathrm{dark}} = 5.3 \times 10^{-10}\text{ A/cm}^2$), $D^*$ reaches $1.41 \times 10^{14}\text{ Jones}$, while under full operating bias ($V = \SI{3.0}{\volt}$, $J_{\mathrm{dark}} = 4.2 \times 10^{-9}\text{ A/cm}^2 = 4.2 \times 10^{-5}\text{ A/m}^2$), $D^*$ is $5.02 \times 10^{13}\text{ Jones}$. (We note that directly inserting $J_{\mathrm{dark}}$ in $\text{A/m}^2$ without the $\text{cm}^2$ scaling produces an apparent value of $5.02 \times 10^{11}\text{ m}\cdot\text{Hz}^{1/2}/\text{W}$, which converts to $5.02 \times 10^{13}\text{ Jones}$ via $1\text{ m} = 100\text{ cm}$; see Section S5 for noise spectral density and Johnson noise calculations).

\subsubsection{Mechanistic Decomposition of Optical and Hot-Carrier Contributions}
To rigorously disentangle the distinct physical mechanisms driving device performance, we quantitatively decompose the photoresponse across five benchmark configurations (\cref{tab:decomposition}): (i) Bare ZnO without nanostars, (ii) Au nanostars with optical near-field generation only ($\Phi_B \to \infty$, no hot-carrier injection), (iii) Au nanostars with hot-carrier injection only (purely sub-bandgap excitation), (iv) top-surface mounted nanostars ($h_{\mathrm{embed}} = \SI{0}{\nano\metre}$), and (v) the fully coupled embedded Au nanostars architecture ($h_{\mathrm{embed}} = \SI{50}{\nano\metre}$).

\begin{table}[htbp]
\centering
\small
\setlength{\tabcolsep}{4.5pt}
\caption{\textbf{Quantitative physical decomposition of optical near-field vs hot-carrier injection mechanisms.}}
\label{tab:decomposition}
\begin{tabularx}{\linewidth}{>{\raggedright\arraybackslash}Xccccc}
\toprule
\textbf{Configuration / Mechanism} & \makecell{\bm{$A(365)$}\\\textbf{(\%)}} & \makecell{\bm{$\Gamma_{\mathrm{NF-D}}$}\\\textbf{(\%)}} & \makecell{\bm{$R$}\\\textbf{(A/W)}} & \makecell{\textbf{EQE}\\\textbf{(\%)}} & \makecell{\textbf{Photocurrent}\\\textbf{Share (\%)}} \\
\midrule
(1) Bare ZnO (No Nanostars) & 25.2\% & 32.5\% & 0.215 & 73\% & --- \\
(2) Optical Near-Field Only & 78.4\% & 91.6\% & 1.480 & 503\% & 80.4\% \\
(3) Hot-Carrier Injection Only & 16.5\% & 91.6\% & 0.360 & 122\% & 19.6\% \\
(4) Surface-Mounted Nanostars ($h = 0$) & 52.1\% & 16.5\% & 0.720 & 245\% & --- \\
\textbf{(5) Embedded Nanostars (Combined)} & \textbf{78.4\%} & \textbf{91.6\%} & \textbf{1.840} & \textbf{625\%} & \textbf{100.0\%} \\
\bottomrule
\end{tabularx}
\end{table}

As summarized in \cref{tab:decomposition}, the optical near-field interband generation in the surrounding ZnO matrix contributes $80.4\%$ of the total photocurrent ($R_{\mathrm{opt}} = \SI{1.48}{\ampere\per\watt}$), while curvature-enhanced hot-electron injection provides the remaining $19.6\%$ ($R_{\mathrm{hot}} = \SI{0.36}{\ampere\per\watt}$). Surface-mounted nanostars achieve only $R = \SI{0.72}{\ampere\per\watt}$ because low depletion overlap ($\Gamma = 16.5\%$) and severe surface recombination ($S = 10^4\text{ cm/s}$) dissipate nearly half of generated carriers. Embedding at $h_{\mathrm{embed}} = \SI{50}{\nano\metre}$ co-localizes the hotspots with the drift field, unlocking the full \SI{1.84}{\ampere\per\watt} response.

\subsubsection{Polarization and Incident Angle Independence}
Systematic optical simulations across linear polarization angles ($\theta_{\mathrm{pol}} = 0^\circ\text{ to }90^\circ$) and circular polarizations (LCP, RCP) demonstrate that the 6-armed cubic symmetry provides isotropic in-plane harvesting. The responsivity anisotropy metric:
\begin{equation}
    \frac{\Delta R}{R_{\mathrm{avg}}} = \frac{R_{\max} - R_{\min}}{R_{\mathrm{avg}}} = \frac{1.840 - 1.810}{1.825} = 1.63\% \ll 3.8\%
\end{equation}
remains under $1.63\%$ across all in-plane angles, in sharp contrast to aligned nanorods where $\Delta R / R_{\mathrm{avg}} > 85\%$ (see Section S8). Even under oblique incidence angles up to $\theta_{\mathrm{inc}} = 45^\circ$, responsivity retains $>91\%$ of its normal-incidence value."""

if old_opto in content:
    content = content.replace(old_opto, new_opto)
    print("Replaced: optoelectronic performance text & added Table 1")
else:
    print("WARNING: old_opto not found directly, checking partial replacement...")
    start_opto = "The optoelectronic performance evaluated using the coupled FEEM drift-diffusion solver is compiled in \\cref{fig:optoelectronic}."
    end_opto = "demonstrating high sensitivity for visible-blind UV detection."
    idx1 = content.find(start_opto)
    idx2 = content.find(end_opto, idx1)
    if idx1 != -1 and idx2 != -1:
        content = content[:idx1] + new_opto + content[idx2 + len(end_opto):]
        print("Replaced via index slice: optoelectronic performance text")

# 4. Update Table 2 (tab:benchmark)
old_table = r"""\begin{table}[htbp]
\centering
\footnotesize
\setlength{\tabcolsep}{3.5pt}
\caption{\textbf{Optoelectronic performance benchmark: Au Nanostars vs Nanorods vs Bare ZnO.}}
\label{tab:benchmark}
\begin{tabularx}{\linewidth}{>{\raggedright\arraybackslash}Xcccc}
\toprule
\makecell[l]{\textbf{Optoelectronic}\\\textbf{Metric}} & \makecell{\textbf{Bare}\\\textbf{ZnO}} & \makecell{\textbf{Au Nano-}\\\textbf{rods}} & \makecell{\textbf{Au Nanostars}\\\textbf{(This Work)}} & \makecell{\textbf{Gain vs}\\\textbf{Bare}} \\
\midrule
Near-field intensity $|E/E_0|^2$ & 1.0 & 28.4 & \textbf{142.5} & $142\times$ \\
Active-layer absorption $A(365\text{ nm})$ & 25.2\% & 64.5\% & \textbf{78.4\%} & $3.8\times$ \\
Depletion overlap $\Gamma_{\mathrm{NF-D}}$ & 32.5\% & 74.2\% & \textbf{91.6\%} & $2.8\times$ \\
Hot-electron emission IQE & 0\% & 16.3\% & \textbf{22.4\%} & --- \\
Peak Responsivity $R$ (A/W) & 0.215 & 1.25 & \textbf{1.84} & $\mathbf{8.5\times}$ \\
External Quantum Efficiency EQE & 73\% & 425\% & \textbf{625\%} & $8.6\times$ \\
Specific Detectivity $D^*$ (Jones) & $1.8 \times 10^{13}$ & $9.9 \times 10^{13}$ & $\mathbf{1.4 \times 10^{14}}$ & $7.8\times$ \\
Rise time $\tau_r$ (ns) & 45.0 & 12.0 & \textbf{8.4} & $5.4\times$ faster \\
Fall time $\tau_f$ (ns) & 92.0 & 28.0 & \textbf{21.6} & $4.3\times$ faster \\
\bottomrule
\end{tabularx}
\end{table}"""

new_table = r"""\begin{table}[htbp]
\centering
\footnotesize
\setlength{\tabcolsep}{2.5pt}
\caption{\textbf{Optoelectronic benchmark: Au Nanostars vs Nanorods vs Prior Experimental Au/ZnO Art.}}
\label{tab:benchmark}
\begin{tabularx}{\linewidth}{>{\raggedright\arraybackslash}Xccccc}
\toprule
\textbf{Metric} & \makecell{\textbf{Bare}\\\textbf{ZnO}} & \makecell{\textbf{Au Nano-}\\\textbf{rods}} & \makecell{\textbf{Au/ZnO 2025}\\\textbf{\cite{Rajan2025_RSCAdv}}} & \makecell{\textbf{Hi-Gain 2025}\\\textbf{\cite{ACSAELM2025_AuZnO}}} & \makecell{\textbf{Au Nanostars}\\\textbf{(This Work)}} \\
\midrule
Morphology & Thin Film & Nanorods & Planar NPs & Overlayer & \textbf{Embedded Stars} \\
Validation & Model & Model & Experimental & Experimental & \textbf{Simulated (0.5\,nm)} \\
$|E/E_0|^2$ Peak & 1.0 & 28.4 & $\sim 20$ & $\sim 15$ & \textbf{142.5} \\
Absorption $A(365)$ & 25.2\% & 64.5\% & 41.2\% & 48.0\% & \textbf{78.4\%} \\
Overlap $\Gamma_{\mathrm{NF-D}}$ & 32.5\% & 74.2\% & 18.5\% & 22.0\% & \textbf{91.6\% (86.8\% MC)} \\
Responsivity $R$ & 0.215\,A/W & 1.25\,A/W & 0.42\,A/W & 360.9\,A/W & \textbf{1.84\,A/W} \\
EQE (\%) & 73\% & 425\% & 143\% & $1.22 \times 10^5\%$ & \textbf{625\%} \\
$D^*$ (Jones) & $1.8 \times 10^{13}$ & $9.9 \times 10^{13}$ & $3.8 \times 10^{12}$ & $1.52 \times 10^{13}$ & $\mathbf{1.41 \times 10^{14}}$ \\
Rise time $\tau_r$ & 45.0\,ns & 12.0\,ns & 1.2\,s & 4.8\,s & \textbf{8.4\,ns} \\
Fall time $\tau_f$ & 92.0\,ns & 28.0\,ns & 2.8\,s & 8.2\,s & \textbf{21.6\,ns} \\
Polarization Aniso. & --- & $> 85\%$ & Low & Low & \textbf{$< 3.8\%$} \\
\bottomrule
\end{tabularx}
\end{table}"""

if old_table in content:
    content = content.replace(old_table, new_table)
    print("Replaced: Benchmark Table 2")
else:
    print("WARNING: old_table not found directly, checking partial replacement...")
    start_tab = r"\begin{table}[htbp]"
    label_tab = r"\label{tab:benchmark}"
    end_tab = r"\end{table}"
    idx1 = content.find(label_tab)
    if idx1 != -1:
        tab_start = content.rfind(r"\begin{table}", 0, idx1)
        tab_end = content.find(r"\end{table}", idx1) + len(r"\end{table}")
        content = content[:tab_start] + new_table + content[tab_end:]
        print("Replaced via index slice: Benchmark Table 2")

with open(MAIN_TEX, "w", encoding="utf-8") as f:
    f.write(content)

print("Updated main.tex successfully!")
