"""
package_submission_zip.py
Prepares:
1. Manuscript_LaTeX_Source.zip:
   Self-contained, fully compilable LaTeX source archive with main.tex, main.bbl,
   bibliography/, figures/, results/figures/, and compiled main.pdf.
2. Complete_Submission_Package.zip:
   All submission assets including Manuscript_LaTeX_Source.zip, Manuscript_Editable.docx,
   main.pdf, supplementary.pdf, cover_letter.pdf, graphical_abstract.pdf/png,
   Response_to_Reviewers.pdf, and submission guide.
"""

import os
import shutil
import zipfile
import subprocess

def create_packages():
    root = os.path.abspath('.')
    sub_dir = os.path.join(root, 'submission')
    latex_pkg_dir = os.path.join(sub_dir, 'Manuscript_LaTeX_Source')
    os.makedirs(latex_pkg_dir, exist_ok=True)
    
    # Target directories inside LaTeX source package
    figs_dir = os.path.join(latex_pkg_dir, 'figures')
    results_figs_dir = os.path.join(latex_pkg_dir, 'results', 'figures')
    bib_dir = os.path.join(latex_pkg_dir, 'bibliography')
    os.makedirs(figs_dir, exist_ok=True)
    os.makedirs(results_figs_dir, exist_ok=True)
    os.makedirs(bib_dir, exist_ok=True)

    # 1. Copy TeX, BBL, and BIB files
    shutil.copy2(os.path.join(root, 'main.tex'), os.path.join(latex_pkg_dir, 'main.tex'))
    shutil.copy2(os.path.join(root, 'main.bbl'), os.path.join(latex_pkg_dir, 'main.bbl'))
    shutil.copy2(os.path.join(root, 'bibliography', 'references.bib'), os.path.join(latex_pkg_dir, 'references.bib'))
    shutil.copy2(os.path.join(root, 'bibliography', 'references.bib'), os.path.join(bib_dir, 'references.bib'))

    # 2. Copy all figures
    fig_source = os.path.join(root, 'manuscript', 'figures')
    for f in os.listdir(fig_source):
        src_path = os.path.join(fig_source, f)
        if os.path.isfile(src_path):
            shutil.copy2(src_path, os.path.join(figs_dir, f))
            shutil.copy2(src_path, os.path.join(results_figs_dir, f))

    # 3. Create README inside LaTeX package
    readme_content = """============================================================
Manuscript LaTeX Source Package
Journal: PLASMONICS (Springer Nature)
Title: Plasmonic Engineering of Embedded Gold Nanostars for Enhanced ZnO
       Ultraviolet Photodetectors via Multi-Physics Inverse Design
Authors: Priyanka and Ram Soorat
============================================================

COMPILATION INSTRUCTIONS:
1. Standard pdflatex compilation:
   pdflatex main.tex
   (main.bbl is included so bibtex is optional, but bibtex main works as well)
   pdflatex main.tex

2. All figures are located in both ./figures/ and ./results/figures/ in
   both high-resolution vector PDF and 300 DPI PNG formats.

3. The source has been compiled and tested with 0 errors and 0 missing references.
============================================================
"""
    with open(os.path.join(latex_pkg_dir, 'README_SUBMISSION.txt'), 'w', encoding='utf-8') as f:
        f.write(readme_content)

    # 4. Verify compilation inside LaTeX source package
    print("Testing compilation inside package directory...")
    res = subprocess.run(['pdflatex', '-interaction=nonstopmode', 'main.tex'], cwd=latex_pkg_dir, capture_output=True, text=True)
    if res.returncode == 0:
        print("LaTeX compilation inside package succeeded with 0 errors!")
    else:
        print("Warning: Compilation returned non-zero code:", res.returncode)

    # 5. Create Manuscript_LaTeX_Source.zip
    zip_latex_root = os.path.join(root, 'Manuscript_LaTeX_Source.zip')
    zip_latex_sub = os.path.join(sub_dir, 'Manuscript_LaTeX_Source.zip')
    for zip_target in [zip_latex_root, zip_latex_sub]:
        if os.path.exists(zip_target):
            os.remove(zip_target)
        with zipfile.ZipFile(zip_target, 'w', zipfile.ZIP_DEFLATED) as zf:
            for foldername, subfolders, filenames in os.walk(latex_pkg_dir):
                # Exclude build junk like .aux, .log, .out
                for filename in filenames:
                    if filename.endswith(('.aux', '.log', '.out', '.blg', '.toc')):
                        continue
                    filepath = os.path.join(foldername, filename)
                    arcname = os.path.relpath(filepath, latex_pkg_dir)
                    zf.write(filepath, arcname)
        print(f"Created: {zip_target} (Size: {os.path.getsize(zip_target)} bytes)")

    # 6. Create Complete_Submission_Package.zip
    comp_pkg_root = os.path.join(root, 'Complete_Submission_Package.zip')
    comp_pkg_sub = os.path.join(sub_dir, 'Complete_Submission_Package.zip')

    submission_items = [
        ('Manuscript_LaTeX_Source.zip', zip_latex_root),
        ('Manuscript_Editable.docx', os.path.join(root, 'Manuscript_Editable.docx')),
        ('main.pdf', os.path.join(root, 'main.pdf')),
        ('supplementary.pdf', os.path.join(root, 'supplementary.pdf')),
        ('supplementary.tex', os.path.join(root, 'supplementary.tex')),
        ('cover_letter.pdf', os.path.join(root, 'cover_letter.pdf')),
        ('cover_letter.tex', os.path.join(root, 'cover_letter.tex')),
        ('graphical_abstract.pdf', os.path.join(root, 'graphical_abstract.pdf')),
        ('graphical_abstract.png', os.path.join(root, 'graphical_abstract', 'graphical_abstract.png') if os.path.exists(os.path.join(root, 'graphical_abstract', 'graphical_abstract.png')) else os.path.join(root, 'results', 'figures', 'fig01_device_schematic.png')),
        ('Response_to_Reviewers.pdf', os.path.join(root, 'Response_to_Reviewers.pdf')),
        ('Response_to_Reviewers.md', os.path.join(root, 'Response_to_Reviewers.md'))
    ]

    for comp_target in [comp_pkg_root, comp_pkg_sub]:
        if os.path.exists(comp_target):
            os.remove(comp_target)
        with zipfile.ZipFile(comp_target, 'w', zipfile.ZIP_DEFLATED) as zf:
            for arcname, fpath in submission_items:
                if os.path.exists(fpath):
                    zf.write(fpath, arcname)
                    print(f"  Added to Complete Package: {arcname}")
                else:
                    print(f"  Notice: File not found to add: {fpath}")
        print(f"Created: {comp_target} (Size: {os.path.getsize(comp_target)} bytes)")

if __name__ == '__main__':
    create_packages()
