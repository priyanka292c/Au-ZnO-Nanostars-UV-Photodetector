import re

with open('main.tex', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Abstract Monte Carlo interval
text = text.replace(r"[1.58, 2.06]\,A/W", r"[1.63, 2.01]\,A/W")

# 2. Section 2.4 Hot-electron efficiency Fermi-Dirac broadening sentence
old_hot_eff = r"elevating the effective internal photoemission efficiency to $\eta_{\mathrm{internal}} = \xi_{\mathrm{tip}} \eta_{\mathrm{planar}} \approx 21.3\% \approx 22.4\%$ across the 3D tip cone with thermal Fermi-Dirac broadening."
new_hot_eff = r"elevating the effective internal photoemission efficiency to $\eta_{\mathrm{internal}} = \xi_{\mathrm{tip}} \eta_{\mathrm{planar}} \approx 21.3\% \approx 22.4\%$ across the 3D tip cone with thermal Fermi-Dirac broadening. The final value of $\eta_{\mathrm{internal}} = 22.4\%$ includes the finite-temperature Fermi--Dirac broadening correction applied to the curvature-enhanced Fowler estimate; it should therefore be interpreted as a model-predicted effective internal photoemission efficiency rather than an experimentally measured interface quantum efficiency."
text = text.replace(old_hot_eff, new_hot_eff)

# 3. Section 3.2 Polarization sentence
text = text.replace(r"provides multi-directional and polarization-insensitive in-plane harvesting.",
                   r"provides low-anisotropy in-plane optical harvesting within the simulated in-plane angular range.")

# 4. Section 3.2 Additive photocurrent sentence
old_add_text = r"The coupled model treats the optical ZnO photogeneration and Au hot-electron injection currents as independent source terms in the carrier-continuity equations; their contributions therefore combine at the photocurrent level ($R_{\mathrm{total}} = R_{\mathrm{opt}} + R_{\mathrm{hot}} = 1.480 + 0.360 = 1.840$\,A/W)."
new_add_text = r"The optical-generation and hot-electron contributions are treated as independent source terms in the carrier continuity equations; the combined photocurrent is therefore obtained by superposition of these source contributions within the adopted sequentially coupled transport model ($R_{\mathrm{total}} = R_{\mathrm{opt}} + R_{\mathrm{hot}} = 1.480 + 0.360 = 1.840$\,A/W)."
text = text.replace(old_add_text, new_add_text)

# 5. Section 3.5 Monte Carlo interval and text
text = text.replace(r"($90\%$ prediction interval $[1.58, 2.06]$\,A/W).", r"($90\%$ prediction interval $[1.63, 2.01]$\,A/W).")
old_mc_p = r"Finally, a 500-run Monte Carlo simulation incorporating Gaussian lithographic variations ($\pm 10\%$ standard deviation in all geometric parameters) yields a mean responsivity of \SI{1.83}{\ampere\per\watt} with a standard deviation of \SI{0.14}{\ampere\per\watt}, defining a $90\%$ prediction interval of $[1.58, 2.06]$\,A/W (\cref{fig:optimization}b, right)."
new_mc_p = r"Finally, a 500-run Monte Carlo computational geometric tolerance analysis incorporating correlated geometric perturbations ($\pm 10\%$ standard deviation; see Section S11) yields a mean responsivity of \SI{1.84}{\ampere\per\watt} with a standard deviation of \SI{0.11}{\ampere\per\watt}, defining a robust $90\%$ prediction interval of $[1.63, 2.01]$\,A/W (\cref{fig:optimization}b)."
text = text.replace(old_mc_p, new_mc_p)

# 6. Table 2 Contextual sentence before the table
context_sentence = r"The reported metrics originate from different device geometries, excitation conditions, and validation methods; therefore, the table is intended for contextual comparison rather than direct one-to-one performance ranking."
if "The reported metrics originate from different device geometries" not in text:
    text = text.replace(r"\begin{table}[htbp]" + "\n" + r"\centering" + "\n" + r"\footnotesize" + "\n" + r"\setlength{\tabcolsep}{2.5pt}" + "\n" + r"\caption{\textbf{Optoelectronic benchmark: Au Nanostars vs Nanorods vs Prior Experimental Au/ZnO Art.}}",
                        context_sentence + "\n\n" + r"\begin{table}[htbp]" + "\n" + r"\centering" + "\n" + r"\footnotesize" + "\n" + r"\setlength{\tabcolsep}{2.5pt}" + "\n" + r"\caption{\textbf{Optoelectronic benchmark: Au Nanostars vs Nanorods vs Prior Experimental Au/ZnO Art.}}")

# 7. Conclusions section overclaiming adjustments
text = text.replace(r"In conclusion, we have demonstrated a comprehensive theoretical and computational framework",
                   r"In conclusion, we have presented a comprehensive theoretical and computational framework")
text = text.replace(r"we established that multibranched nanostars dramatically outperform conventional nanorods and spherical nanoparticles.",
                   r"the simulations predict substantially enhanced performance relative to the modeled reference architectures.")
text = text.replace(r"isotropic multi-directional hot-carrier injection",
                   r"low-anisotropy, multi-directional hot-carrier injection")

with open('main.tex', 'w', encoding='utf-8') as f:
    f.write(text)

print('Updated main.tex with final reviewer requirements.')
