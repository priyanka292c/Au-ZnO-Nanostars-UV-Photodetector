import re

words = ['isotropic', 'singularity', 'global optimum', 'manufacturing robustness', 'manufacturing tolerance', 'eliminated']

files = ['main.tex', 'supplementary.tex', 'cover_letter.tex', 'graphical_abstract.tex']

for f in files:
    with open(f, 'r', encoding='utf-8') as fp:
        content = fp.read()
    for w in words:
        matches = list(re.finditer(re.escape(w), content, re.IGNORECASE))
        if matches:
            print(f'In {f}, found {len(matches)} occurrences of "{w}":')
            for m in matches:
                start = max(0, m.start() - 40)
                end = min(len(content), m.end() + 40)
                print('   ...', repr(content[start:end]), '...')
