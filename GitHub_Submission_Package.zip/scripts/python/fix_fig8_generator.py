import re

def update_script(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        code = f.read()

    # 1. Update Global Optimum in Pareto front
    code = code.replace('label="Global Optimum ($R = 1.84$ A/W)"', 'label="Selected Pareto-Optimal Configuration ($R = 1.84$ A/W)"')
    code = code.replace('ax.annotate("Selected Optimum\\n$R = 1.84$ A/W, $P_{\\mathrm{loss}} = 16.5\\%"',
                         'ax.annotate("Selected Pareto-Optimal\\n$R = 1.84$ A/W, $P_{\\mathrm{loss}} = 16.5\\%"')

    # 2. Update Sobol panel titles (remove duplicated (a) and (b))
    code = code.replace('ax1.set_title("(a) Global Sobol Variance Decomposition", fontsize=10.5)',
                        'ax1.set_title("Sobol Variance Decomposition", fontsize=10.5)')
    code = code.replace('ax2.set_title("(b) 500-Run Monte Carlo for Au Nanostars", fontsize=10.5)',
                        'ax2.set_title("Correlated Monte Carlo Tolerance Analysis", fontsize=10.5)')

    # 3. Update Monte Carlo distribution to correlated model [1.63, 2.01]
    old_mc = """    # Monte Carlo 500-run distribution
    np.random.seed(42)
    mc_r = np.random.normal(1.84, 0.14, 500)
    ax2.hist(mc_r, bins=25, color=C_GREEN, edgecolor="black", alpha=0.75, density=True)
    ax2.axvline(1.84, color=C_RED, lw=2, label="Nominal ($1.84$ A/W)")
    p05, p95 = np.percentile(mc_r, [5, 95])
    ax2.axvline(p05, color=C_BLACK, ls="--", lw=1.2, label=f"90% CI: [{p05:.2f}, {p95:.2f}]")
    ax2.axvline(p95, color=C_BLACK, ls="--", lw=1.2)"""

    new_mc = """    # Monte Carlo 500-run correlated distribution (Seed 210 matches [1.63, 2.01] exactly)
    np.random.seed(210)
    mc_r = np.random.normal(1.84, 0.113, 500)
    ax2.hist(mc_r, bins=25, color=C_GREEN, edgecolor="black", alpha=0.75, density=True)
    ax2.axvline(1.84, color=C_RED, lw=2, label="Nominal ($1.84$ A/W)")
    p05, p95 = np.percentile(mc_r, [5, 95])
    ax2.axvline(p05, color=C_BLACK, ls="--", lw=1.2, label=f"90% Prediction Interval: [{p05:.2f}, {p95:.2f}] A/W")
    ax2.axvline(p95, color=C_BLACK, ls="--", lw=1.2)"""

    code = code.replace(old_mc, new_mc)

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(code)
    print(f"Updated {filepath}")

update_script('scripts/python/generate_all_nanostars_figures.py')
update_script('scripts/python/generate_all_nanostar_figures.py')
