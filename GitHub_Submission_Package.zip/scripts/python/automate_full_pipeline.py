#!/usr/bin/env python3
# ============================================================================
# automate_full_pipeline.py — Master End-to-End Orchestrator
# ============================================================================
"""
Orchestrates the entire computational pipeline:
  1. Inverse design & surrogate modeling (nanostar_inverse_design.py)
  2. Automated MATLAB multi-physics suite: FDTD + FEEM + BEM (automate_fdtd_feem_bem_nanostars.m)
  3. Publication figure generation with 0.5 nm mesh & plural Nanostars (generate_all_nanostars_figures.py)
  4. Numerical dataset CSV export (export_all_nanostars_csv.py)
  5. LaTeX compilation of manuscript, SI, cover letter, GA, and protocol
"""

import os
import sys
import shutil
import subprocess

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

def run_cmd(cmd, cwd):
    print(f"\n[EXEC] {cmd} (in {cwd})")
    res = subprocess.run(cmd, shell=True, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if res.returncode != 0:
        print(f"[FAIL] Return code: {res.returncode}")
        print(res.stdout[-500:])
        return False
    else:
        print("[SUCCESS]")
        return True

def main():
    print("=" * 75)
    print("  AUTOMATING FULL NANOSTARS COMPUTATIONAL PIPELINE & MANUSCRIPT BUILD")
    print("  0.5 nm Mesh Discretization | FDTD + FEEM + BEM MATLAB & Python")
    print("=" * 75)

    py_dir = os.path.join(BASE_DIR, "scripts", "python")
    matlab_dir = os.path.join(BASE_DIR, "scripts", "bem_matlab")
    
    # 1. Inverse Design
    print("\n--- STAGE 1: GP-BO & Pareto Multi-Objective Inverse Design ---")
    run_cmd(f"{sys.executable} nanostar_inverse_design.py", py_dir)

    # 2. Automated MATLAB FDTD + FEEM + BEM Suite
    if shutil.which("matlab"):
        print("\n--- STAGE 2: Automated MATLAB FDTD + FEEM + BEM Simulation Suite ---")
        run_cmd('matlab -batch "automate_fdtd_feem_bem_nanostars; exit"', matlab_dir)
    else:
        print("\n[NOTE] MATLAB binary not in PATH; skipping direct MATLAB batch.")

    # 3. Figure Generation
    print("\n--- STAGE 3: Publication Figure Generation (0.5 nm Mesh, PDF + PNG) ---")
    run_cmd(f"{sys.executable} generate_all_nanostars_figures.py", py_dir)

    # 4. CSV Dataset Export
    print("\n--- STAGE 4: Publication Dataset CSV Export ---")
    run_cmd(f"{sys.executable} export_all_nanostars_csv.py", py_dir)

    # 5. LaTeX Document Compilations
    print("\n--- STAGE 5: Compiling Publication LaTeX Documents ---")
    docs = [
        ("manuscript", "pdflatex -interaction=nonstopmode main.tex && bibtex main && pdflatex -interaction=nonstopmode main.tex"),
        ("supplementary", "pdflatex -interaction=nonstopmode supplementary.tex"),
        ("cover_letter", "pdflatex -interaction=nonstopmode cover_letter.tex"),
        ("graphical_abstract", "pdflatex -interaction=nonstopmode graphical_abstract.tex"),
        ("experimental_protocol", "pdflatex -interaction=nonstopmode protocol.tex")
    ]

    for folder, compile_cmd in docs:
        target_dir = os.path.join(BASE_DIR, folder)
        if os.path.exists(target_dir):
            print(f"\nBuilding {folder}...")
            run_cmd(compile_cmd, target_dir)

    # Also build root tex files if present
    for tex_file in ["main.tex", "supplementary.tex", "cover_letter.tex", "graphical_abstract.tex", "protocol.tex"]:
        if os.path.exists(os.path.join(BASE_DIR, tex_file)):
            stem = os.path.splitext(tex_file)[0]
            print(f"\nBuilding root {tex_file}...")
            run_cmd(f"pdflatex -interaction=nonstopmode {tex_file}", BASE_DIR)

    print("\n" + "=" * 75)
    print("  ALL STAGES COMPLETED SUCCESSFULLY!")
    print("=" * 75)

if __name__ == "__main__":
    main()
