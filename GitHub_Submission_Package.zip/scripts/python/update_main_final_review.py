import re

with open('main.tex', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Update Abstract: 3.8x vs 3.11x, isotropic -> multi-directional/polarization-insensitive, manufacturing -> computational tolerance
old_abs_target = r"delivering a 3.8-fold boost in active-layer optical absorption over unpatterned ZnO on quartz ($3.11\times$ relative to planar-backed ZnO)."
new_abs_target = r"delivering a 3.8-fold enhancement in active-layer optical absorption relative to unpatterned ZnO on quartz (3.11-fold relative to the planar-backed ZnO reference)."
text = text.replace(old_abs_target, new_abs_target)

text = text.replace("quasi-polarization-independent optical harvesting", "multi-directional and polarization-insensitive optical harvesting")
text = text.replace("A 500-run Monte Carlo manufacturing tolerance study confirms computational robustness", "A 500-run Monte Carlo computational tolerance study confirms geometric robustness")
text = text.replace("provides a viable route toward high-sensitivity", "provides a numerically supported design route toward high-sensitivity")
text = text.replace("shielding photocarriers from non-radiative surface recombination", "substantially suppressing surface recombination losses")
text = text.replace("demonstrate theoretically that embedded", "theoretically predict that embedded")

# 2. Section 1 & 2: Singularity -> concentration, isotropic -> multi-directional and polarization-insensitive
text = text.replace(r"\textbf{Extreme Multi-Tip Near-Field Singularity (Mechanism A):}", r"\textbf{Extreme Multi-Tip Near-Field Concentration (Mechanism A):}")
text = text.replace("lightning-rod field singularity", "lightning-rod field concentration")
text = text.replace("lightning-rod field singularities", "lightning-rod field concentration")
text = text.replace("the internal quantum efficiency reaches $\\eta_{\\mathrm{internal}} \\approx 22.4\\%$", "predicts an effective internal photoemission efficiency of approximately $22.4\\%$ using the curvature-corrected Fowler model")

# 3. Section 2.4: Hot-hole qualification
old_hothole = r"Because hot holes lack the energy to overcome this massive barrier ($E_{\mathrm{hole}} \ll \Delta E_v$), hot-hole injection is energetically forbidden, leaving hot-electron injection as the sole operative mechanism (see Section S4)."
new_hothole = r"Within the adopted Au/ZnO band-alignment model, because hot holes lack the energy to overcome this massive barrier ($E_{\mathrm{hole}} \ll \Delta E_v$), hot-hole injection is energetically suppressed, leaving hot-electron injection as the primary operative carrier injection mechanism (see Section S4)."
text = text.replace(old_hothole, new_hothole)

# 4. Fix undefined references in main.tex:
text = text.replace(r"(evaluated across grid sizes of \SI{4.0}{\nano\metre}, \SI{2.0}{\nano\metre}, \SI{1.0}{\nano\metre}, \SI{0.5}{\nano\metre}, and \SI{0.25}{\nano\metre}; see Section S1 and \cref{tab:mesh_conv})", r"(evaluated across grid sizes of \SI{4.0}{\nano\metre}, \SI{2.0}{\nano\metre}, \SI{1.0}{\nano\metre}, \SI{0.5}{\nano\metre}, and \SI{0.25}{\nano\metre}; see Supplementary Section S1 and Table S1)")
text = text.replace(r"(with an ensemble mean of $86.8 \pm 3.4\%$ across 500 Monte Carlo tolerance variations; see Section S6 and \cref{tab:monte_carlo})", r"(with an ensemble mean of $86.8 \pm 3.4\%$ across 500 Monte Carlo tolerance variations; see Supplementary Sections S5 and S6)")

# 5. Section 3.1 & Fig 4 caption: 3.8x vs 3.11x
text = text.replace(r"demonstrating a peak 3.8-fold improvement at $\lambda = \SI{365}{\nano\metre}$.", r"demonstrating a 3.8-fold enhancement relative to unpatterned ZnO on quartz (3.11-fold relative to the planar-backed ZnO reference) at $\lambda = \SI{365}{\nano\metre}$.")
text = text.replace(r"This corresponds to a 3.82-fold ($3.8\times$) absorption enhancement relative to bare unpatterned ZnO on quartz, and a 3.11-fold ($3.11\times$) enhancement relative to bare ZnO on a planar Au back-reflector.", r"This corresponds to a 3.8-fold enhancement relative to unpatterned ZnO on quartz (3.11-fold relative to the planar-backed ZnO reference).")

# 6. Section 3.3: Detectivity qualification sentence
old_det_text = r"see Section S5 for noise spectral density and Johnson noise calculations)."
new_det_text = r"see Section S5 for noise spectral density and Johnson noise calculations). This value represents the ideal shot-noise-limited detectivity derived from the simulated dark-current density; experimentally measured detectivity may be lower because of Johnson, 1/f, generation-recombination, contact, and readout noise."
text = text.replace(old_det_text, new_det_text)

# 7. Section 3.2: Table 1 additive photocurrent explanation
old_table1_caption = r"\caption{\textbf{Quantitative physical decomposition of optical near-field vs hot-carrier injection mechanisms.}}"
new_table1_caption = r"\caption{\textbf{Quantitative physical decomposition of optical near-field vs hot-carrier injection mechanisms (at $\lambda = 365$\,nm, $P_{\mathrm{in}} = 10$\,W/m$^2$, $V_{\mathrm{bias}} = 3$\,V).}}"
text = text.replace(old_table1_caption, new_table1_caption)

old_table1_post = r"As summarized in \cref{tab:decomposition}, the optical near-field interband generation"
new_table1_post = r"The coupled model treats the optical ZnO photogeneration and Au hot-electron injection currents as independent source terms in the carrier-continuity equations; their contributions therefore combine at the photocurrent level ($R_{\mathrm{total}} = R_{\mathrm{opt}} + R_{\mathrm{hot}} = 1.480 + 0.360 = 1.840$\,A/W). As summarized in \cref{tab:decomposition}, the optical near-field interband generation"
text = text.replace(old_table1_post, new_table1_post)

# 8. Section 3.2: Isotropic wording
text = text.replace("provides isotropic in-plane harvesting.", "provides multi-directional and polarization-insensitive in-plane harvesting.")

# 9. Section 3.4 & 3.5: Global optimum -> Pareto-optimal, manufacturing tolerance -> computational tolerance
text = text.replace("identifying the global optimum at $R = \\SI{1.84}{\\ampere\\per\\watt}$", "identifying the selected Pareto-optimal configuration at $R = \\SI{1.84}{\\ampere\\per\\watt}$")
text = text.replace("The global optimum at $r_{\\mathrm{core}} = \\SI{15}{\\nano\\metre}$", "The numerically identified optimum within the defined design space at $r_{\\mathrm{core}} = \\SI{15}{\\nano\\metre}$")
text = text.replace("500-run Monte Carlo manufacturing tolerance distribution", "500-run Monte Carlo computational geometric tolerance distribution")
text = text.replace("manufacturing tolerances ($\\pm 10\\%$)", "assumed fabrication-variation tolerances ($\\pm 10\\%$)")

# 10. Table 2: Benchmark table - make validation type and numerical prediction unambiguous
old_bench_val = r"Validation & Model & Model & Experimental & Experimental & \textbf{Simulated (0.5\,nm)} \\"
new_bench_val = r"Validation Type & Model & Model & Experimental & Experimental & \textbf{Numerical Prediction$^*$} \\"
text = text.replace(old_bench_val, new_bench_val)

old_bench_end = r"\bottomrule" + "\n" + r"\end{tabularx}" + "\n" + r"\end{table}"
new_bench_end = r"\bottomrule" + "\n" + r"\end{tabularx}" + "\n" + r"\vspace{0.3em}\raggedright\footnotesize $^*$Values for the present work are simulation predictions from our multi-physics model and have not been experimentally validated." + "\n" + r"\end{table}"
text = text.replace(old_bench_end, new_bench_end)

# 11. Add speed comparison positioning sentence before or in conclusion
speed_novelty_text = r"Unlike trap-dominated high-gain Au/ZnO architectures (e.g., \cite{ACSAELM2025_AuZnO}), the present model targets the responsivity--speed trade-off through depletion-assisted carrier extraction, achieving sub-10-nanosecond response ($\tau_r = \SI{8.4}{\nano\second}$) at high responsivity ($R = \SI{1.84}{\ampere\per\watt}$)."
if "Unlike trap-dominated high-gain Au/ZnO architectures" not in text:
    text = text.replace(r"\subsection{Temporal Switching Dynamics}", speed_novelty_text + "\n\n" + r"\subsection{Temporal Switching Dynamics}")

# 12. Conclusion: Update isotropic, 3.8x vs 3.11x, manufacturing tolerance
old_conc_p = r"generates extreme lightning-rod field singularities ($|E/E_0|^2 \approx 142.5$) and isotropic multi-directional hot-carrier injection directly coupled to the \SI{365}{\nano\metre} excitonic band-edge of ZnO."
new_conc_p = r"generates extreme lightning-rod field concentration ($|E/E_0|^2 \approx 142.5$) and multi-directional, polarization-insensitive hot-carrier injection directly coupled to the \SI{365}{\nano\metre} excitonic band-edge of ZnO, delivering a 3.8-fold enhancement in active-layer optical absorption relative to unpatterned ZnO on quartz (3.11-fold relative to the planar-backed ZnO reference)."
text = text.replace(old_conc_p, new_conc_p)

text = text.replace("robust computational manufacturing tolerance", "robust computational geometric tolerance")
text = text.replace("establishes multibranched plasmonic nanostructures as a compelling paradigm", "computationally demonstrates multibranched plasmonic nanostructures as a promising design route")

with open('main.tex', 'w', encoding='utf-8') as f:
    f.write(text)

print('Successfully updated main.tex with all requested revisions.')
