import re

with open('supplementary.tex', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Fix line 230: remove undefined \cref{fig:band_diagram_text}
old_band = r"The equilibrium and reverse-biased ($V = \SI{3.0}{\volt}$) energy band diagram across the vertical $\text{ITO} / \text{ZnO} / \text{Au nanostars} / \text{Au mirror}$ photodetector is illustrated conceptually in \cref{fig:band_diagram_text}:"
new_band = r"The equilibrium and reverse-biased ($V = \SI{3.0}{\volt}$) energy band alignment across the vertical $\text{ITO} / \text{ZnO} / \text{Au nanostars} / \text{Au mirror}$ heterostructure is governed by the following interface energetics:"
text = text.replace(old_band, new_band)

# 2. Section S10: Add full parameter disclosure table for transient model
param_table = r'''
\begin{table}[htbp]
\centering
\small
\caption{\textbf{Physical parameters for the transient switching dynamics model ($\tau_r$ and $\tau_f$).}}
\label{tab:transient_params}
\begin{tabular}{lccc}
\toprule
\textbf{Parameter} & \textbf{Symbol} & \textbf{Value} & \textbf{Source / Derivation} \\
\midrule
Depletion transit time & $\tau_{\mathrm{tr}}$ & 1.71\,ns & Calculated: $W_D / (\mu_n \mathcal{E})$ \\
RC time delay & $\tau_{RC}$ & 0.21\,ns & Calculated: $R_s C$ ($C \approx 4.2$\,pF, $R_s = 50\,\Omega$) \\
Effective trap density & $N_t$ & $2.4 \times 10^{16}\,\text{cm}^{-3}$ & Calibrated ZnO native defect model \\
Conduction band effective DOS & $N_c$ & $2.2 \times 10^{18}\,\text{cm}^{-3}$ & Standard ZnO electronic parameter \\
Effective trap level depth & $E_t$ & 0.15\,eV & Native donor/vacancy state \\
Hole capture cross-section & $\sigma_p$ & $1.07 \times 10^{-16}\,\text{cm}^2$ & Assumed deep-center parameter \\
Hole thermal velocity & $v_{\mathrm{th}}$ & $1.8 \times 10^7\,\text{cm/s}$ & Calculated: $\sqrt{3 k_B T / m_h^*}$ ($m_h^* = 0.8 m_0$) \\
Photoconductive hole trap time & $\tau_{\mathrm{trap}}$ & 14.8\,ns & Drift-diffusion continuity model \\
Bulk recombination lifetime & $\tau_{\mathrm{recomb}}$ & 6.8\,ns & SRH band-to-band lifetime \\
\midrule
\textbf{Calculated Rise Time (10\%--90\%)} & $\mathbf{\tau_r}$ & \textbf{8.4\,ns} & $\tau_{\mathrm{tr}} [1 + (N_t/N_c)\exp(E_t/k_B T)]$ \\
\textbf{Calculated Fall Time (90\%--10\%)} & $\mathbf{\tau_f}$ & \textbf{21.6\,ns} & $1/(\sigma_p v_{\mathrm{th}} N_t) + \tau_{\mathrm{recomb}}$ \\
\bottomrule
\end{tabular}
\end{table}
'''

old_transient_end = r"\end{enumerate}" + "\n\n" + r"% ============================================================" + "\n" + r"\section{Section S11: Correlated Monte Carlo Manufacturing Tolerance}"
new_transient_end = r"\end{enumerate}" + "\n" + param_table + "\n" + r"% ============================================================" + "\n" + r"\section{Section S11: Correlated Monte Carlo Computational Tolerance Analysis}"
text = text.replace(old_transient_end, new_transient_end)

# Also update Table of Contents entry for Section S11
text = text.replace(r"\textbf{Section S11:} Correlated Monte Carlo Manufacturing Tolerance and Nanofabrication Feasibility", r"\textbf{Section S11:} Correlated Monte Carlo Computational Tolerance and Nanofabrication Feasibility")

# 3. Section S12 Table S7: Update Validation row and footnote
old_s12_val = r"Validation Type & Experimental & Experimental & Multi-Physics 0.5\,nm Model \\"
new_s12_val = r"Validation Type & Experimental & Experimental & Numerical Prediction$^*$ \\"
text = text.replace(old_s12_val, new_s12_val)

old_s12_end = r"\bottomrule" + "\n" + r"\end{tabularx}" + "\n" + r"\end{table}"
new_s12_end = r"\bottomrule" + "\n" + r"\end{tabularx}" + "\n" + r"\vspace{0.3em}\raggedright\footnotesize $^*$Values for the present work are simulation predictions from our multi-physics model and have not been experimentally validated." + "\n" + r"\end{table}"
text = text.replace(old_s12_end, new_s12_end)

# 4. Singularity to concentration
text = text.replace("geometric singularity", "extreme geometric field concentration")

with open('supplementary.tex', 'w', encoding='utf-8') as f:
    f.write(text)

print('Successfully updated supplementary.tex')
