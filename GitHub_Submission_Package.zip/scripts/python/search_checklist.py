import re

checklist_terms = [
    'Global Optimum',
    'isotropic',
    'manufacturing robustness',
    'manufacturing validation',
    'dramatically',
    '[1.63, 2.07]',
    '4.85',
    '88.4%',
    '87.5%',
    '24.9 A/m',
    '1 nm mesh',
    'surface recombination eliminated'
]

files = ['main.tex', 'supplementary.tex', 'cover_letter.tex', 'graphical_abstract.tex']

for f in files:
    with open(f, 'r', encoding='utf-8') as fp:
        content = fp.read()
    for term in checklist_terms:
        matches = list(re.finditer(re.escape(term), content, re.IGNORECASE))
        if matches:
            print(f'[{f}] FOUND {len(matches)} matches of "{term}":')
            for m in matches:
                start = max(0, m.start() - 35)
                end = min(len(content), m.end() + 35)
                print('   ...', repr(content[start:end]), '...')

print("Checklist search complete.")
