with open('main.log', 'r', encoding='utf-8', errors='ignore') as f:
    mlog = f.read()

with open('supplementary.log', 'r', encoding='utf-8', errors='ignore') as f:
    slog = f.read()

m_undef = [line for line in mlog.splitlines() if 'undefined' in line.lower()]
s_undef = [line for line in slog.splitlines() if 'undefined' in line.lower()]

print(f"main.log undefined count: {len(m_undef)}")
for l in m_undef:
    print("   main.log:", l)

print(f"supplementary.log undefined count: {len(s_undef)}")
for l in s_undef:
    print("   supplementary.log:", l)
