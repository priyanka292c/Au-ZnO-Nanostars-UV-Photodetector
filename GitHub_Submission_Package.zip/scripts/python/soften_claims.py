import re

with open('main.tex', 'r', encoding='utf-8') as f:
    text = f.read()

# Soften "dramatically"
text = text.replace("can dramatically enhance light harvesting", "can substantially enhance light harvesting")
text = text.replace("compress dramatically into the nanoscale apex", "compress intensely into the nanoscale apex")
text = text.replace("dramatically expanding the momentum escape cone", "substantially expanding the momentum escape cone")
text = text.replace("dramatically enlarging the effective optical cross-section", "substantially enlarging the effective optical cross-section")

# Check and soften any remaining overclaiming
text = text.replace("we establish rigorous computational manufacturing tolerances", "we perform a rigorous computational geometric tolerance analysis")
text = text.replace("demonstrating that Au surface functionalization enhances", "showing that Au surface functionalization enhances")

with open('main.tex', 'w', encoding='utf-8') as f:
    f.write(text)

print('Softened dramatically and related terms in main.tex')
