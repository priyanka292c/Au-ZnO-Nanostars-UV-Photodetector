import re

with open('Response_to_Reviewers.tex', 'r', encoding='utf-8') as f:
    text = f.read()

# Replace any markdown backticks
text = text.replace('`results/figures/`', r'\texttt{results/figures/}')
text = text.replace('`results/csv/`', r'\texttt{results/csv/}')
text = text.replace('`cover_letter.tex`', r'\texttt{cover\_letter.tex}')
text = text.replace('`cover_letter.pdf`', r'\texttt{cover\_letter.pdf}')
text = text.replace('`bibliography/references.bib`', r'\texttt{bibliography/references.bib}')

# Add graphicx
if 'usepackage{graphicx}' not in text:
    text = text.replace(r'\usepackage{amsmath,amssymb}', r'\usepackage{amsmath,amssymb}' + '\n' + r'\usepackage{graphicx}')

# Add author
if r'\author{' not in text:
    text = text.replace(r'\date{\today}', r'\author{Priyanka and Ram Soorat}' + '\n' + r'\date{\today}')

# Wrap tables with \resizebox{\textwidth}{!}{...} to ensure zero overfull hboxes
tables_to_wrap = [
    (r'\begin{tabular}{lccccc}', r'\end{tabular}'),
    (r'\begin{tabular}{lcccccc}', r'\end{tabular}'),
    (r'\begin{tabular}{lcccc}', r'\end{tabular}'),
    (r'\begin{tabular}{lcc}', r'\end{tabular}')
]

# We will wrap tabular blocks in \resizebox{\textwidth}{!}{...}
def wrap_tabular(match):
    content = match.group(0)
    if 'resizebox' in content:
        return content
    return r'\resizebox{\textwidth}{!}{%' + '\n' + content + '\n}'

# Use regex to wrap tabular in resizebox
text = re.sub(r'\\begin\{tabular\}\{[^}]+\}.*?\\end\{tabular\}', wrap_tabular, text, flags=re.DOTALL)

# Add bibliography before \end{document}
bib_text = r'''
\begin{thebibliography}{99}
\bibitem{Rajan2025_RSCAdv}
A.~Rajan, K.~Arora, B.~Vidhani, and P.~Kumar, ``Gold-nanoparticle-decorated {ZnO} thin-film ultraviolet photodetectors,'' \textit{RSC Adv.}, vol.~15, pp.~8186--8196, 2025.
\bibitem{Mortensen2014_Nonlocal}
N.~A. Mortensen, S.~Raza, M.~Wubs, T.~S{\o}ndergaard, and S.~I. Bozhevolnyi, ``A generalized non-local optical response theory for plasmonic nanostructures,'' \textit{Nat. Commun.}, vol.~5, p.~3809, 2014.
\bibitem{Govorov2014_NanoToday}
A.~O. Govorov, H.~Zhang, and Y.~K. Gun'ko, ``Theory of photoinjection of hot plasmonic carriers from metal nanocrystals into semiconductors,'' \textit{Nano Today}, vol.~9, no.~1, pp.~85--101, 2014.
\bibitem{Giugni2013_NatNano}
A.~Giugni et al., ``Hot-electron nanoscopy using adiabatic compression of surface plasmons,'' \textit{Nat. Nanotechnol.}, vol.~8, no.~11, pp.~845--852, 2013.
\bibitem{Kumar2025_ACSAELM}
P.~Kumar et al., ``High-performance plasmon-enhanced ultraviolet photodetectors,'' \textit{ACS Appl. Electron. Mater.}, vol.~7, pp.~1757--1765, 2025.
\end{thebibliography}
'''

if r'\begin{thebibliography}' not in text:
    text = text.replace(r'\end{document}', bib_text + '\n' + r'\end{document}')

with open('Response_to_Reviewers.tex', 'w', encoding='utf-8') as f:
    f.write(text)

print('Successfully processed Response_to_Reviewers.tex')
