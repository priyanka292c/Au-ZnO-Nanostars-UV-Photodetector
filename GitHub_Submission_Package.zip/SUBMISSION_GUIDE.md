# Journal Submission Guide: Editable Files & Source Packages

**Target Journal:** *Plasmonics* (Springer Nature)  
**Article Title:** *Plasmonic Engineering of Embedded Gold Nanostars for Enhanced ZnO Ultraviolet Photodetectors via Multi-Physics Inverse Design*  
**Authors:** Priyanka and Ram Soorat  

---

## 1. Why Did You See the Warning Message?

> ⚠️ *"We prefer editable files over PDFs. Upload the original editable source file (for example, .docx) to ensure proper review."*

This is the standard notice displayed by Springer Nature (Editorial Manager / SNAPP) when a PDF is selected for the **"Manuscript"** item type. Journal production systems require an **editable format** (Word `.docx` or LaTeX source `.tex` with figures and `.bbl`) so the publisher's typesetting engine can generate proofs and galley copies.

---

## 2. Available Editable Files & Packages

Both options are prepared and verified in your workspace:

### Option A (Recommended for Quickest, Error-Free Upload): Word `.docx`
* **File:** [`Manuscript_Editable.docx`](file:///d:/Priyanka/Research/Submitted/Under%20editor/Computational%20Inverse%20Design%20of%20Plasmon-Enhanced%20ZnO%20Nanostars/Manuscript_Editable.docx) (Size: 4.68 MB)
* **What it contains:** 
  - Complete article formatted in Times New Roman (11.5 pt, 1-inch margins).
  - Strict author list: **Priyanka and Ram Soorat** (no "Dr.", correct affiliations).
  - All Sections 1 through 6 with full text and formatted formulas.
  - All 17 figures embedded in 300 DPI high resolution with updated Figure 3 caption and callouts.
  - Native formatted publication tables (Table 1: Mechanism decomposition, Table 2: Benchmark comparison).
  - Declarations and all 37 formatted references.
* **Portal action:** Upload this file as **Item Type: "Manuscript"**. The warning message will immediately disappear.

---

### Option B (For Full LaTeX Submission): LaTeX Source `.zip`
* **File:** [`Manuscript_LaTeX_Source.zip`](file:///d:/Priyanka/Research/Submitted/Under%20editor/Computational%20Inverse%20Design%20of%20Plasmon-Enhanced%20ZnO%20Nanostars/Manuscript_LaTeX_Source.zip) (Size: 19.27 MB)
* **What it contains:**
  - `main.tex`: Pristine LaTeX source code.
  - `main.bbl`: Pre-compiled bibliography (enables 1-click compilation on any editorial server without requiring external BibTeX runs).
  - `references.bib` & `bibliography/references.bib`: Full BibTeX database.
  - `figures/` & `results/figures/`: All 17 vector `.pdf` and 300 DPI `.png` figures.
  - `main.pdf`: Reference compiled 24-page article.
  - `README_SUBMISSION.txt`: Instructions for production editors.
* **Portal action:** In systems supporting LaTeX zip archives, upload `Manuscript_LaTeX_Source.zip` under **Item Type: "Manuscript / LaTeX Source"**.

---

## 3. Item-by-Item Upload Checklist for Journal Submission Portal

| Portal Upload Slot (Item Type) | Recommended File to Upload | Description / Notes |
| :--- | :--- | :--- |
| **Manuscript** *(Editable Source)* | [`Manuscript_Editable.docx`](file:///d:/Priyanka/Research/Submitted/Under%20editor/Computational%20Inverse%20Design%20of%20Plasmon-Enhanced%20ZnO%20Nanostars/Manuscript_Editable.docx) *(or `Manuscript_LaTeX_Source.zip`)* | Eliminates the editable-file warning banner completely. |
| **Supplementary Material** | [`supplementary.pdf`](file:///d:/Priyanka/Research/Submitted/Under%20editor/Computational%20Inverse%20Design%20of%20Plasmon-Enhanced%20ZnO%20Nanostars/supplementary.pdf) | Comprehensive Supplementary Information (Mesh, GNOR, BEM, Pareto). |
| **Cover Letter** | [`cover_letter.pdf`](file:///d:/Priyanka/Research/Submitted/Under%20editor/Computational%20Inverse%20Design%20of%20Plasmon-Enhanced%20ZnO%20Nanostars/cover_letter.pdf) | Addressed to Editor-in-Chief of *Plasmonics*. |
| **Response to Reviewers** | [`Response_to_Reviewers.pdf`](file:///d:/Priyanka/Research/Submitted/Under%20editor/Computational%20Inverse%20Design%20of%20Plasmon-Enhanced%20ZnO%20Nanostars/Response_to_Reviewers.pdf) | Detailed point-by-point rebuttal with Section 5 on Figure 3. |
| **Graphical Abstract** | [`graphical_abstract.pdf`](file:///d:/Priyanka/Research/Submitted/Under%20editor/Computational%20Inverse%20Design%20of%20Plasmon-Enhanced%20ZnO%20Nanostars/graphical_abstract.pdf) or [`graphical_abstract.png`](file:///d:/Priyanka/Research/Submitted/Under%20editor/Computational%20Inverse%20Design%20of%20Plasmon-Enhanced%20ZnO%20Nanostars/results/figures/fig01_device_schematic.png) | Dedicated graphical summary of the multi-physics design. |

---

## 4. Master Archive (Everything in One File)

* **Archive:** [`Complete_Submission_Package.zip`](file:///d:/Priyanka/Research/Submitted/Under%20editor/Computational%20Inverse%20Design%20of%20Plasmon-Enhanced%20ZnO%20Nanostars/Complete_Submission_Package.zip) (Size: 27.07 MB)
* Bundles all of the above documents in a single zip archive for your backups or off-line submission.
