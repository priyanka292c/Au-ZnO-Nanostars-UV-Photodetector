# Computational Inverse Design of Plasmon-Enhanced ZnO Ultraviolet Photodetectors Using Embedded Gold Nanostars

This repository contains the complete research suite, manuscript, multi-physics simulation codes, automation scripts, and publication-ready datasets for:

> **"Plasmonic Engineering of Embedded Gold Nanostars for Enhanced ZnO Ultraviolet Photodetectors via Multi-Physics Inverse Design"**  
> *Authors:* Priyanka and Ram Soorat  
> *Target Journal:* **Plasmonics** (Springer Nature)

---

## 🌟 Key Physical Highlights & Performance Benchmark

| Optoelectronic Metric | Bare ZnO | Au Nanorod | **Au Nanostar (This Work)** | Enhancement Factor |
| :--- | :---: | :---: | :---: | :---: |
| **Peak Near-Field Intensity $|E/E_0|^2$** | $1.0$ | $28.4$ | **$142.5$** | **$142.5\times$ boost** |
| **Active-Layer Absorption $A(365\text{ nm})$** | $25.2\%$ | $64.5\%$ | **$78.4\%$** | **$3.8\times$ vs quartz (3.11$\times$ vs Au back)** |
| **Field-Depletion Overlap $\Gamma_{\mathrm{NF-D}}$** | $32.5\%$ | $74.2\%$ | **$91.6\%$** | **$91.6\%$ inside depletion** |
| **Hot-Electron Internal Emission IQE** | $0\%$ | $16.3\%$ | **$22.4\%$** | Curvature-assisted |
| **Peak Responsivity $R$ at 365 nm** | $0.215\text{ A/W}$ | $1.25\text{ A/W}$ | **$1.84\text{ A/W}$** | **$8.5\times$ vs Bare ZnO** |
| **External Quantum Efficiency (EQE)** | $73\%$ | $425\%$ | **$625\%$** | Photoconductive gain $G \approx 8.70$ |
| **Specific Detectivity $D^*$** | $1.8 \times 10^{13}\text{ Jones}$ | $9.9 \times 10^{13}\text{ Jones}$ | **$1.41 \times 10^{14}\text{ Jones}$** | **Shot-noise-limited** |
| **Switching Rise Time $\tau_r$** | $45.0\text{ ns}$ | $12.0\text{ ns}$ | **$8.4\text{ ns}$** | **$5.4\times$ faster** |
| **Switching Fall Time $\tau_f$** | $92.0\text{ ns}$ | $28.0\text{ ns}$ | **$21.6\text{ ns}$** | **$4.3\times$ faster** |

---

## 📁 Repository Structure

```
nanostar_plasmon_zno/
├── manuscript/                    # Full publication manuscript (Plasmonics)
│   ├── main.tex                   # Complete LaTeX source
│   ├── main.pdf                   # Compiled publication-ready PDF (19 pages)
│   └── figures/                   # All 17 embedded vector figures
├── supplementary/                 # Supplementary Information document
│   ├── supplementary.tex          # Complete LaTeX SI source
│   └── supplementary.pdf          # Compiled SI PDF (4 pages)
├── cover_letter/                  # Formal submission cover letter
│   ├── cover_letter.tex           # LaTeX source
│   └── cover_letter.pdf           # Compiled PDF
├── graphical_abstract/            # Standalone TikZ Graphical Abstract
│   ├── graphical_abstract.tex     # LaTeX source
│   └── graphical_abstract.pdf     # Compiled vector PDF
├── experimental_protocol/         # Experimental synthesis & fabrication protocol
│   ├── protocol.tex               # Complete LaTeX protocol
│   └── protocol.pdf               # Compiled protocol PDF
├── bibliography/
│   └── references.bib             # De-duplicated, verified BibTeX database
├── results/
│   ├── figures/                   # 17 Publication figures (PDF + 300 DPI PNG)
│   └── csv/                       # 9 Exported numerical datasets
└── scripts/
    ├── fdtd/                      # Lumerical FDTD Scripts (1 nm mesh override)
    │   ├── build_nanostar_geometry.lsf
    │   ├── materials_nanostar.lsf
    │   ├── mesh_nanostar.lsf      # 1 nm uniform mesh refinement
    │   ├── sources_nanostar.lsf
    │   ├── monitors_nanostar.lsf
    │   ├── run_nanostar_sweep.lsf
    │   └── export_nanostar_data.lsf
    ├── feem/                      # Finite-element drift-diffusion solver
    │   └── feem_nanostar_drift_diffusion.m
    ├── bem_matlab/                # Boundary Element Method plasmonics
    │   ├── bem_nanostar_plasmonics.m
    │   └── run_fdtd_feem_bem_nanostar.m
    └── python/                    # Python automation & inverse design suite
        ├── run_fdtd_nanostar.py
        ├── nanostar_inverse_design.py
        ├── generate_all_nanostar_figures.py
        ├── export_all_nanostar_csv.py
        └── automate_full_pipeline.py
```

---

## 🚀 Execution & Automation Instructions

### 1. Run Complete End-to-End Pipeline
```bash
python scripts/python/automate_full_pipeline.py
```
This executes inverse design optimization, generates all 17 figures at 300 DPI, exports CSV datasets, and compiles all LaTeX documents.

### 2. Run MATLAB Electrodynamics & Multi-Physics Suite
Open MATLAB, navigate to `scripts/bem_matlab/`, and execute:
```matlab
run_fdtd_feem_bem_nanostar
```

### 3. Run Lumerical FDTD (1 nm Mesh)
Open Lumerical FDTD Solutions, load and execute in sequence:
```lsf
scripts/fdtd/materials_nanostar.lsf
scripts/fdtd/build_nanostar_geometry.lsf
scripts/fdtd/mesh_nanostar.lsf
scripts/fdtd/sources_nanostar.lsf
scripts/fdtd/monitors_nanostar.lsf
run;
scripts/fdtd/export_nanostar_data.lsf
```
