# Generation–Depletion Co-Localization and Carrier Extraction in Embedded Au Nanostar-Enhanced ZnO Ultraviolet Photodetectors: A Multiphysics Modelling Study

**Authors:** Priyanka$^{1,*}$ and Ram Soorat$^{2,*}$  
**Affiliations:**  
$^{1}$ Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India  
$^{2}$ School of Technology, Woxsen University, Hyderabad 502345, Telangana, India  
**Target Journal:** *Optical and Quantum Electronics* (Springer Nature)  
**Repository:** `https://github.com/priyanka292c/Au-ZnO-Nanostars-UV-Photodetector`

---

## Key Scientific Findings (Verified Numerical Metrics)

- **Decoupling Near-Field Intensity from Responsivity:** Across 80 simulated device configurations, peak electromagnetic near-field intensity ($|E/E_0|^2 = 142.5$ at optimized tip apexes) accounts for only 10.5% of responsivity variance ($R^2 = 0.105$). In contrast, the **Plasmonic–Depletion Overlap Factor** ($\Gamma_{\mathrm{PD}} = 91.6\%$ at $h_{\mathrm{embed}} = 50\text{ nm}$, $W_D = 65.4\text{ nm}$) accounts for **92.9%** of the responsivity variance within the investigated design space ($r = 0.964$ [95% CI: $0.945\text{--}0.978$], $R^2 = 0.929$ [95% CI: $0.893\text{--}0.956$]).
- **Adjoint Reciprocity & 3D FEEM Verification:** Donolato adjoint collection efficiency ($\eta_{\mathrm{col}} = 93.2\%$ analytical vs. $95.7\%$ 3D FEEM, a $2.68\%$ relative shift) and terminal photocurrent density ($18.40\text{ A m}^{-2}$ homogenized 1D mirror-inclusive vs. $18.84\text{ A m}^{-2}$ 3D FEEM, $+2.39\%$) confirm cross-scale transport fidelity.
- **UV Photodetector Performance ($\lambda = 365\text{ nm}$, $V = 3\text{ V}$, $P_{\mathrm{in}} = 10\text{ W m}^{-2}$):**
  - **Standard Operating Regime:** $\mathcal{R} = 1.834\text{ A W}^{-1}$, $\mathrm{EQE} = 623.1\%$ (under conditional effective photoconductive gain $G = 8.36$; $8.36\times$ over combined single-pass baseline $\mathcal{R}_0 = 0.2195\text{ A W}^{-1}$, $8.53\times$ over planar bare ZnO), $D^* = 5.00 \times 10^{13}\text{ Jones}$ ($1.22 \times 10^{14}\text{ Jones}$ at $0.5\text{ V}$).
  - **Continuous Mirror-Inclusive Model:** $\mathcal{R} = 1.840\text{ A W}^{-1}$, $\mathrm{EQE} = 625.0\%$, $D^* = 5.02 \times 10^{13}\text{ Jones}$, $I_{\mathrm{photo}}/I_{\mathrm{dark}} \approx 4.4 \times 10^5$ ($J_{\mathrm{dark}} = 4.2 \times 10^{-9}\text{ A cm}^{-2}$).
  - **Mechanistic Decomposition ($G = 8.36$):** Interband optical carrier collection contributes **98.0%** ($1.798\text{ A W}^{-1}$), while curvature-enhanced Fowler hot-electron injection contributes **2.0%** ($0.036\text{ A W}^{-1}$).
  - **Polarization Isotropy & Transient Kinetics:** Negligible linear polarization sensitivity ($\Delta\mathcal{R}/\mathcal{R}_{\mathrm{avg}} = 1.63\%$ vs. $88.8\%$ for the off-resonant Au nanorod benchmark) and fast pulse switching ($\tau_r = 8.4\text{ ns}$, $\tau_f = 21.2\text{ ns}$ under a $40\text{ ns}$ optical pulse).

---

## Repository Contents

| Path | Description |
|---|---|
| `OQE_Revised_Manuscript.pdf` / `.tex` / `.bbl` | Main research manuscript (48 pages) prepared for *Optical and Quantum Electronics* |
| `OQE_Supplementary_Information.pdf` / `.tex` / `.bbl` | Supplementary Information (39 pages, Sections S1–S13) with full derivations and sensitivity tables |
| `OQE_Cover_Letter.pdf` / `.tex` | Submission cover letter (1 page) |
| `references_acs.bib`, `unsrturl.bst` | Complete BibTeX database and Springer-compatible URL bibliography style |
| `verify_reported_numerical_results.py` | Standalone Python replication script auditing all key analytical & transport metrics |
| `OQE_Figures/` | Publication figures `fig01`–`fig10` and `graphical_abstract` in vector `.pdf` and 300-DPI `.png` |
| `OQE_Code_and_Data/` | Python reproduction & inverse-design scripts (`generate_acs_10_figures.py`, `nanostar_inverse_design.py`, `export_all_nanostar_csv.py`), 14 raw CSV datasets, and `nanorod_benchmark/` |
| `scripts/` | Electrodynamic and transport solver scripts: Lumerical FDTD (`fdtd/*.lsf`), MATLAB BEM (`bem_matlab/*.m`), and FEEM drift–diffusion (`feem/*.m`) |
| `submission_docs/` | Synchronized Microsoft Word (`.docx`) submission documents, literature gap analysis, validation report, and checklist |
| `LICENSE` | MIT Open Source License |

---

## Quick Verification & Compilation

### 1. Numerical Verification Audit
```bash
pip install numpy scipy matplotlib pandas
python verify_reported_numerical_results.py
```

### 2. Compile Manuscript PDF from LaTeX Source
```bash
pdflatex OQE_Revised_Manuscript.tex
bibtex OQE_Revised_Manuscript
pdflatex OQE_Revised_Manuscript.tex
pdflatex OQE_Revised_Manuscript.tex
```

---

## License and Citation

Released under the **MIT License** (`LICENSE`). If you use these simulation models, datasets, or the $\Gamma_{\mathrm{PD}}$ formulation, please cite:

```bibtex
@article{Priyanka2026_ZnO_Nanostars_OQE,
  author  = {Priyanka and Soorat, Ram},
  title   = {Generation--Depletion Co-Localization and Carrier Extraction in Embedded Au Nanostar-Enhanced ZnO Ultraviolet Photodetectors: A Multiphysics Modelling Study},
  journal = {Optical and Quantum Electronics},
  year    = {2026},
  note    = {Submitted}
}
```
