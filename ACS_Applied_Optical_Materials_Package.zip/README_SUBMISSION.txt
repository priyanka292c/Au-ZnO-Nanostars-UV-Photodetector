======================================================================
Manuscript LaTeX Source Package
Target Journal: ACS Applied Optical Materials (ACS Publications)
Article Title:  Generation--Depletion Co-Localization in Embedded Au Nanostar-Enhanced
                ZnO Ultraviolet Photodetectors
Authors:        Priyanka and Ram Soorat
======================================================================

COMPILATION INSTRUCTIONS:
1. Main Manuscript:
   cd manuscript
   pdflatex ACS_Manuscript.tex
   bibtex ACS_Manuscript
   pdflatex ACS_Manuscript.tex
   pdflatex ACS_Manuscript.tex

2. Supporting Information:
   cd ../supplementary
   pdflatex ACS_Supplementary_Information.tex
   bibtex ACS_Supplementary_Information
   pdflatex ACS_Supplementary_Information.tex
   pdflatex ACS_Supplementary_Information.tex

3. Cover Letter:
   cd ../docs
   pdflatex Cover_Letter_ACS.tex

All figures are located in ../figures/ in both high-resolution vector PDF
and 300 DPI publication-grade PNG formats.
The LaTeX source has been tested and verified with 0 errors and 0 overfull boxes.
======================================================================
