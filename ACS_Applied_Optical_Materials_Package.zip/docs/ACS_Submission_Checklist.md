# ACS Applied Optical Materials Submission Verification Checklist

### Manuscript Details
- **Title:** *Generation–Depletion Co-Localization in Embedded Au Nanostar-Enhanced ZnO Ultraviolet Photodetectors*
- **Target Journal:** *ACS Applied Optical Materials* (ACS Publications)
- **Manuscript Type:** Research Article
- **Submission Portal:** ACS Paragon Plus Environment
- **Editorial Assessment Readiness Score:** **9.0 / 10** (Fully calibrated against editorial critique)

---

### Master Submission Audit Matrix

| Section / Requirement | Specific ACS Guideline | Verification Status | Verification Notes & Location |
|---|---|---|---|
| **1. Target Scope & Positioning** | Applied optical materials, nanophotonics, device optoelectronics | **PASSED** | Positioned on optical generation–depletion physics, multiphysics coupling, and device responsivity |
| **2. Scientific Demarcation** | Clearly distinct from accepted *Plasmonics* nanorod paper | **PASSED** | 3D multipolar nanostar vs 1D dipole; decoupling discovery ($R^2 = 0.105$); generalized $\Gamma_{\mathrm{PD}}$ ($R^2 = 0.929$); reduced polarization sensitivity |
| **3. Non-Fabrication Rule** | Computational study without claiming physical fabrication | **PASSED** | Strictly employs "simulated", "predicted", "modeled"; explicitly reserves physical fabrication for future work (Sec. 11) |
| **4. Manuscript Title** | Concise, impactful, under 20 words | **PASSED** | 10 words; selected from 7 candidate evaluations (`docs/Candidate_Titles.md`) |
| **5. Abstract** | Structured, concise (<250 words), quantitative, no references | **PASSED** | 212 words; includes 1.84 A/W, 8.56$\times$, 91.6% $\Gamma_{\mathrm{PD}}$, $R^2 = 0.929$ vs $0.105$, $5.02 \times 10^{13}$ Jones, 5-fold CV $R^2 = 0.956$ |
| **6. Keywords** | 5–8 indexed ACS keywords | **PASSED** | 6 keywords: *Au nanostars, ZnO, UV photodetectors, localized surface plasmon resonance, generation–depletion co-localization, inverse design* |
| **7. Manuscript Class & Compilation** | `achemso` or standard LaTeX compiling cleanly to PDF | **PASSED** | `manuscript/ACS_Manuscript.pdf` compiled cleanly (37 pages, 0 errors, MiKTeX 25.12) |
| **8. Table of Contents (TOC) Graphic** | Exact dimensions: $8.25 \times 4.45$\,cm ($3.25 \times 1.75$\,in) | **PASSED** | `figures/graphical_abstract.pdf` / `.png` rendered at exact $8.25 \times 4.45$\,cm |
| **9. Figure Quality & Resolution** | Single ($8.25$\,cm) / Double ($17.1$\,cm) width; $\ge 300$\,dpi; colorblind safe | **PASSED** | 10 publication-quality figures in both vector `.pdf` and 300 dpi `.png` (`docs/Figure_Audit_Report.md`) |
| **10. Numerical Consistency** | Exact numerical alignment across all text, tables, and figures | **PASSED** | 1.84 A/W, bare 0.215 A/W, 8.56$\times$, $W_D = 65.4$\,nm, $\Gamma_{\mathrm{PD}} = 91.6\%$, $R^2 = 0.929$, $80.4\%$ interband vs $19.6\%$ hot-carrier |
| **11. Supporting Information (SI)** | Distinct document with S-numbered sections, figures, and tables | **PASSED** | `supplementary/ACS_Supplementary_Information.pdf` compiled cleanly (13 pages, Sections S1–S12, 0 errors) |
| **12. Quantum Nonlocality Validation** | Defense against classical apex singularities ($r_{\mathrm{apex}} = 2$\,nm) | **PASSED** | GNOR promoted to main text (Sec. 4.3) + SI Sec. S5; proves responsivity shifts by only $2.7\%$ ($1.84 \to 1.79$\,A/W) |
| **13. Hot-Carrier Fallback Defense** | Proof that discovery holds even without Fowler injection | **PASSED** | Section 9 & Figure 9 prove $\eta_i = 0\%$ yields $1.480$\,A/W (6.88$\times$ enhancement from interband generation alone) |
| **14. Circularity Defense** | Multivariate regression & cross-validation | **PASSED** | Section 6.1 & Table 3: OLS model $R^2 = 0.961$, $\beta^*_{\Gamma_{\mathrm{PD}}} = 0.988$ ($p < 10^{-52}$), partial $R^2 = 0.941$, 5-fold $R^2_{\mathrm{CV}} = 0.956 \pm 0.011$ |
| **15. Bibliography & DOIs** | Complete citations, zero hallucinated sources, verified DOIs | **PASSED** | 87 references in `references/references_acs.bib`, 100% verified DOIs, 1 self-citation (1.15%) (`docs/Reference_Audit_Report.md`) |
| **16. Cover Letter** | Formal ACS editorial letter with 5 suggested reviewers | **PASSED** | `docs/Cover_Letter_ACS.pdf` compiled cleanly (3 pages, professional phrasing, 0 errors) |
| **17. Highlights** | 3–5 bullet points summarizing core breakthrough | **PASSED** | 5 concise bullet points in `docs/Highlights.md` |
| **18. Reviewer-Risk Defense** | Proactive rebuttals for top 10 potential reviewer criticisms | **PASSED** | Full 10-point rebuttal report in `docs/Reviewer_Risk_Report.md` |

---

### Certification of Submission Readiness

All 10 mandatory editorial criteria have been fully resolved:
1. Replaced "topology-independent" with "topology-transferable" throughout the text, captions, and conclusions.
2. Replaced "complete polarization insensitivity" with "substantially reduced polarization sensitivity under normal-incidence excitation ($\Delta\mathcal{R}/\mathcal{R}_{\mathrm{avg}} = 1.63\%$)".
3. Removed the unexplained 3.8% polarization threshold.
4. Replaced "high-speed switching" with "model-predicted intrinsic transient rise time of $\tau_r = 8.4$\,ns".
5. Replaced "explains 92.9% of variance" with "the linear model based on $\Gamma_{\mathrm{PD}}$ accounts for 92.9% of the variance in calculated responsivity".
6. Added full multivariate regression ($\mathcal{R} = \beta_0 + \beta_1 \Gamma_{\mathrm{PD}} + \beta_2 A_{\mathrm{ZnO}} + \beta_3 |E/E_0|^2 + \epsilon$), partial $R^2$ analysis, and 5-fold cross-validation in Section 6.1 and Table 3 to defeat the circularity criticism.
7. Promoted the GNOR quantum nonlocal screening results into the main body of the paper (Section 4.3).
8. Rewrote the Cover Letter to present the prior nanorod study professionally and objectively.
9. Clarified that the 80 points represent deterministic simulated design configurations within the computational parameter space.
10. Focused the final claims on the two investigated architectures (nanorods and nanostars) rather than universal topology independence, and appropriately identified detectivity as shot-noise-limited predicted detectivity.
