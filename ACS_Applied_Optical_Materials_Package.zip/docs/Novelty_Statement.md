# Novelty Statement: Scientific Differentiation from Prior Work

**Target Journal:** *ACS Applied Optical Materials*  
**Manuscript Title:** Generation–Depletion Co-Localization in Embedded Au Nanostar-Enhanced ZnO Ultraviolet Photodetectors  
**Authors:** Priyanka and Ram Soorat  

---

### Context with Authors' Prior Accepted Work:
The authors previously published an accepted study:
> **“Plasmonic Engineering of Embedded Gold Nanorods for Enhanced ZnO Ultraviolet Photodetectors via Multi-Physics Inverse Design”**, *Plasmonics*, 2026.

### Why This Manuscript Represents a Genuinely Distinct and Non-Redundant Contribution:
1. **From 1D Uniaxial Dipoles to 3D Multibranched Hybridization:**
   The previous study focused exclusively on an elongated Au nanorod. Nanorods operate as uniaxial dipoles whose near-field enhancement is restricted to two hemispherical end-caps along the major axis, exhibiting strong polarization dependence ($\Delta\mathcal{R}/\mathcal{R} > 85\%$) and requiring oblique incidence or strict TM polarization. In contrast, the present manuscript investigates a three-dimensional multibranched Au nanostar possessing cubic ($O_h$) symmetry. Branch–core hybridization tunes a direct resonant mode to the ZnO band-edge ($\lambda = 365$\,nm), creating six acute lightning-rod hotspots simultaneously ($|E/E_0|^2 \approx 142.5$, a 5-fold increase over nanorods) and enabling substantially reduced polarization sensitivity under normal-incidence excitation ($\Delta\mathcal{R}/\mathcal{R}_{\mathrm{avg}} = 1.63\%$).

2. **From Field-Based Overlap ($\Gamma_{\mathrm{NF-D}}$) to Generation Overlap ($\Gamma_{\mathrm{PD}}$):**
   The nanorod paper introduced a field-based overlap concept ($\Gamma_{\mathrm{NF-D}}$) that evaluated electromagnetic field intensity. In complex multibranched architectures with sharp apexes, field intensity maps alone are fundamentally misleading: high local fields occur inside the metal and across unpassivated interfaces without yielding collectable carriers. The present work formulates the generalized **Plasmonic–Depletion Generation Overlap Factor ($\Gamma_{\mathrm{PD}}$)**, integrating the actual spatial optical carrier generation rate $G_{\mathrm{opt}}(\mathbf{r})$ within the semiconductor host. This generalization isolates the true optoelectronic contribution, excluding parasitic metal dissipation.

3. **Peak Near-Field Intensity Alone is a Weak Predictor of Responsivity:**
   The central scientific discovery of this manuscript is that peak plasmonic field enhancement is decoupled from photodetector responsivity ($R^2 = 0.105$, $r = 0.324$), whereas $\Gamma_{\mathrm{PD}}$ quantitatively describes device responsivity across 80 simulated design configurations ($R^2 = 0.929$, $r = 0.964$). The linear model accounts for $92.9\%$ of the variance in calculated responsivity, retaining dominant predictive significance in multivariate regression with 5-fold cross-validation ($R^2_{\mathrm{CV}} = 0.956 \pm 0.011$). For example, a surface-mounted nanostar produces intense near fields ($|E/E_0|^2 \approx 95.0$), yet delivers a responsivity of only $0.720$\,A\,W$^{-1}$---far lower than an embedded nanorod with $|E/E_0|^2 \approx 28.4$ ($1.250$\,A\,W$^{-1}$)---because poor overlap ($\Gamma_{\mathrm{PD}} = 16.5\%$) wastes photocarriers in the recombination-dominated neutral bulk.

4. **Topology-Transferable Design Principle:**
   This paper asks the fundamental nanophotonics question: *Does the co-localization principle survive when the plasmonic topology is fundamentally transformed from an elongated rod to a branched star?* By quantitatively demonstrating that $\Gamma_{\mathrm{PD}} \to \eta_{\mathrm{col}} \to \mathcal{R}$ governs device response across both morphologies, this work establishes generation--depletion co-localization as a topology-transferable design principle within the investigated plasmonic architectures.
