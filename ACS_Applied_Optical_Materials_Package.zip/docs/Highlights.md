# Manuscript Highlights

**Journal:** *ACS Applied Optical Materials*  
**Title:** Generation–Depletion Co-Localization in Embedded Au Nanostar-Enhanced ZnO Ultraviolet Photodetectors  
**Authors:** Priyanka and Ram Soorat  

---

1. **Peak Near-Field Intensity Alone is a Weak Predictor:** Peak plasmonic near-field intensity ($|E/E_0|^2$) is only weakly correlated with photodetector responsivity ($R^2 = 0.105$). Across 80 simulated design configurations, the linear model based on generation–depletion overlap ($\Gamma_{\mathrm{PD}}$) accounts for $92.9\%$ of the variance in calculated responsivity ($R^2 = 0.929$, $p < 10^{-15}$), retaining dominant predictive significance in multivariate regression with 5-fold cross-validation ($R^2_{\mathrm{CV}} = 0.956 \pm 0.011$).
2. **Topology Transfer from Nanorods to Nanostars:** Branched 6-arm Au nanostars overcome the strong polarization dependence of 1D nanorods, providing substantially reduced polarization sensitivity under normal-incidence excitation ($\Delta\mathcal{R}/\mathcal{R}_{\mathrm{avg}} = 1.63\%$) and acute apex field amplification ($|E/E_0|^2 \approx 142.5$).
3. **High-Performance UV Photodetection:** Optimally embedding the nanostars at $h_{\mathrm{embed}} = 50$\,nm in 200\,nm ZnO under 3\,V reverse bias achieves $\Gamma_{\mathrm{PD}} = 91.6\%$ and carrier collection efficiency $\eta_{\mathrm{col}} = 88.5\%$, delivering a predicted responsivity of 1.84\,A\,W$^{-1}$ (8.56-fold enhancement over bare ZnO), $\mathrm{EQE} = 625\%$, shot-noise-limited predicted detectivity $D^* = 5.02 \times 10^{13}$\,Jones ($1.22 \times 10^{14}$\,Jones at 0.5\,V), and a model-predicted intrinsic transient rise time of $\tau_r = 8.4$\,ns.
4. **Dominance of Optical Generation:** Optical interband generation contributes 80.4\% ($1.480$\,A\,W$^{-1}$) and curvature-enhanced Fowler hot electrons provide 19.6\% ($0.360$\,A\,W$^{-1}$); a 6.88-fold enhancement over bare ZnO survives even under complete hot-carrier quenching.
5. **Topology-Transferable Design Principles:** Demonstrates that while plasmonic geometry transforms the spatial hotspot distribution, generation–depletion co-localization represents a topology-transferable design principle across the elongated and multibranched architectures investigated here.
